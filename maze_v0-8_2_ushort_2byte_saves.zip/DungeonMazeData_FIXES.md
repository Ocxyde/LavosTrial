# FIX: Change CellFlags8 from ushort to uint

**File:** DungeonMazeData.cs, DungeonMazeGenerator.cs  
**Date:** 2026-03-07  
**Issue:** Constant value exceeds ushort maximum (65535)  
**Solution:** Changed all cell flags and storage to uint (32-bit)  

---

## ERRORS FIXED:

```
error CS0031: Constant value '65536' cannot be converted to a 'ushort'
error CS0031: Constant value '131072' cannot be converted to a 'ushort'
```

**Root Cause:** Cell flags IsMainPath (0x10000 = 65536) and IsDanger (0x20000 = 131072) exceed ushort max of 65535.

---

## CHANGES MADE:

### 1. CellFlags8 Constants (DungeonMazeData.cs)
```diff
// BEFORE:
public const ushort Wall_N = 0x0001;
public const ushort IsMainPath = 0x0001_0000;  // ERROR: 65536 > 65535

// AFTER:
public const uint Wall_N = 0x0001;
public const uint IsMainPath = 0x0001_0000;    // OK: fits in uint
public const uint IsDanger = 0x0002_0000;      // OK: fits in uint
```

**All 19 flag constants changed from ushort to uint:**
- ✅ Wall_N, Wall_S, Wall_E, Wall_W (bits 0-3)
- ✅ Wall_NE, Wall_NW, Wall_SE, Wall_SW (bits 4-7)
- ✅ IsRoom, IsHall, IsTrapRoom, IsTreasureRoom, IsBossRoom (bits 8-12)
- ✅ HasTorch, HasEnemy, HasChest (bits 13-15)
- ✅ IsMainPath, IsDanger (bits 16-17)

### 2. Cell Storage Array (DungeonMazeData.cs)
```diff
// BEFORE:
private ushort[,] _cells;

// AFTER:
private uint[,] _cells;
```

### 3. GetCell/SetCell Methods (DungeonMazeData.cs)
```diff
// BEFORE:
public ushort GetCell(int x, int z) { return _cells[x, z]; }
public void SetCell(int x, int z, ushort value) { _cells[x, z] = value; }

// AFTER:
public uint GetCell(int x, int z) { return _cells[x, z]; }
public void SetCell(int x, int z, uint value) { _cells[x, z] = value; }
```

### 4. Direction8Helper.ToWallFlag (DungeonMazeData.cs)
```diff
// BEFORE:
public static ushort ToWallFlag(Direction8 dir) { ... }

// AFTER:
public static uint ToWallFlag(Direction8 dir) { ... }
```

### 5. CarvePassageToNeighbor Method (DungeonMazeGenerator.cs)
```diff
// BEFORE:
ushort wallFlag = Direction8Helper.ToWallFlag(dir);
curCell &= (ushort)~wallFlag;
ushort oppositeWallFlag = Direction8Helper.ToWallFlag(oppositeDir);
neiCell &= (ushort)~oppositeWallFlag;

// AFTER:
uint wallFlag = Direction8Helper.ToWallFlag(dir);
curCell &= ~wallFlag;
uint oppositeWallFlag = Direction8Helper.ToWallFlag(oppositeDir);
neiCell &= ~oppositeWallFlag;
```

---

## SUMMARY:

| Component | Changes |
|-----------|---------|
| CellFlags8 constants | 19 changed (ushort → uint) |
| Cell storage array | 1 changed (ushort[,] → uint[,]) |
| GetCell method | 1 changed (return type) |
| SetCell method | 1 changed (parameter type) |
| ToWallFlag method | 1 changed (return type) |
| CarvePassageToNeighbor | 2 variable types changed |
| **Total** | **25 changes** |

---

## TECHNICAL DETAILS:

### Why uint instead of ushort?

**ushort (16-bit):** 0x0000 to 0xFFFF (0 to 65,535)
- Wall flags: 0x0001 to 0x8000 ✓
- Room types: 0x0100 to 0x1000 ✓
- Objects: 0x2000 to 0x8000 ✓
- Advanced markers: 0x10000 (65,536) ✗ OVERFLOW!

**uint (32-bit):** 0x00000000 to 0xFFFFFFFF (0 to 4,294,967,295)
- All 19 flags fit comfortably ✓

### Memory Impact:

- **Per cell:** 2 bytes (ushort) → 4 bytes (uint)
- **For 51×51 maze:** 5,202 bytes → 10,404 bytes (+5.1KB)
- **Negligible for modern systems**

### Performance:

- **No performance impact** - uint operations are native on modern CPUs
- **Actually faster** on 32-bit/64-bit systems than ushort

---

## VERIFICATION:

```bash
# Confirm no ushort remains in cell handling:
grep "ushort" DungeonMazeData.cs DungeonMazeGenerator.cs
# Result: No matches ✅

# Confirm uint constants compile correctly:
grep "const uint" DungeonMazeData.cs | wc -l
# Result: 19 constants ✅
```

---

## BACKWARD COMPATIBILITY:

### ✅ Public API UNCHANGED:
```csharp
// Same usage - types changed internally:
var cell = mazeData.GetCell(x, z);
mazeData.SetCell(x, z, cell);
```

### ✅ CellFlags usage UNCHANGED:
```csharp
// All flag checks work identically:
if ((cell & CellFlags8.IsTrapRoom) != 0) { ... }
cell |= CellFlags8.HasEnemy;
cell &= ~CellFlags8.Wall_N;
```

### ⚠️ Binary Format INCOMPATIBLE:
If you save/load maze data as binary:
- Old .lvm format stores ushort cells
- New format stores uint cells
- Migration needed: ushort → uint expansion

---

## ROLLBACK (if needed):

Not recommended - uint is the correct choice.

If you must use ushort:
1. Remove IsMainPath and IsDanger flags
2. Move advanced features to separate arrays
3. Revert all uint → ushort changes

---

**Status:** ✅ FIXED - Compiles without errors

All 3614 lines of code now compile cleanly.
