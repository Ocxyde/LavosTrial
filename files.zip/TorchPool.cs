using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// TORCHPOOL — Pool d'objets pour les torches.
///
/// FONCTIONNEMENT :
///  - Les GameObjects de torche sont créés une fois puis désactivés (pas détruits).
///  - À la régénération, ils sont réactivés et repositionnés → zéro allocation.
///  - Si le nouveau labyrinthe a besoin de plus de torches que le pool,
///    il crée les manquantes et les ajoute au pool.
///  - ReleaseAll() remet toutes les torches en réserve sans les détruire.
///
/// SETUP : Attache sur le même GameObject que MazeRenderer.
/// </summary>
public class TorchPool : MonoBehaviour
{
    // ─── Pool ─────────────────────────────────────────────────────────────────
    private readonly List<GameObject>      _pool   = new List<GameObject>();
    private readonly List<TorchController> _active = new List<TorchController>();
    private Transform                      _poolRoot;

    // ─────────────────────────────────────────────────────────────────────────
    void Awake()
    {
        _poolRoot = new GameObject("TorchPool_Inactive").transform;
        _poolRoot.SetParent(transform);
        _poolRoot.gameObject.SetActive(false); // Cache tout le conteneur
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  RÉCUPÉRER UNE TORCHE (depuis le pool ou nouvelle création)
    // ─────────────────────────────────────────────────────────────────────────

    /// <summary>
    /// Retourne une torche prête à l'emploi, repositionnée et réinitialisée.
    /// </summary>
    public TorchController Get(Vector3 position, Quaternion rotation,
                               Transform activeParent, Texture2D[] flameFrames,
                               Material flameMat, Material handleMat)
    {
        GameObject go;

        if (_pool.Count > 0)
        {
            // Réutilise depuis le pool
            go = _pool[_pool.Count - 1];
            _pool.RemoveAt(_pool.Count - 1);
        }
        else
        {
            // Crée une nouvelle torche et l'ajoute au pool pour la prochaine fois
            go = BuildTorchObject(flameMat, handleMat);
        }

        // Repositionne et rattache au parent actif
        go.transform.SetParent(activeParent);
        go.transform.position = position;
        go.transform.rotation = rotation;
        go.SetActive(true);

        // Réinitialise le controller
        var ctrl = go.GetComponent<TorchController>();
        var flameMR = go.transform.Find("Flame")?.GetComponent<Renderer>();
        var light   = go.transform.Find("FlameLight")?.GetComponent<Light>();
        ctrl.Initialize(flameFrames, flameMR, light);

        _active.Add(ctrl);
        return ctrl;
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  LIBÉRER TOUTES LES TORCHES ACTIVES → retour dans le pool
    // ─────────────────────────────────────────────────────────────────────────

    /// <summary>
    /// Désactive toutes les torches actives et les remet en réserve.
    /// Appeler avant chaque régénération de labyrinthe.
    /// </summary>
    public void ReleaseAll()
    {
        foreach (var ctrl in _active)
        {
            if (ctrl == null) continue;
            var go = ctrl.gameObject;
            go.SetActive(false);
            go.transform.SetParent(_poolRoot);
            _pool.Add(go);
        }
        _active.Clear();
        Debug.Log($"[TorchPool] {_pool.Count} torche(s) remise(s) en réserve.");
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  DESTRUCTION COMPLÈTE (fin de session)
    // ─────────────────────────────────────────────────────────────────────────

    /// <summary>Détruit toutes les torches (pool + actives). Appeler à la fin du jeu.</summary>
    public void DestroyAll()
    {
        ReleaseAll();
        foreach (var go in _pool)
            if (go != null) Destroy(go);
        _pool.Clear();
    }

    void OnDestroy() => DestroyAll();

    // ─────────────────────────────────────────────────────────────────────────
    //  CONSTRUCTION D'UNE TORCHE (interne)
    // ─────────────────────────────────────────────────────────────────────────

    private GameObject BuildTorchObject(Material flameMat, Material handleMat)
    {
        var torchGO = new GameObject("Torch");

        // ── Support (bâton) ────────────────────────────────────────────────
        var handle = GameObject.CreatePrimitive(PrimitiveType.Quad);
        handle.name = "Handle";
        handle.transform.SetParent(torchGO.transform);
        handle.transform.localPosition = Vector3.zero;
        handle.transform.localRotation = Quaternion.identity;
        handle.transform.localScale    = new Vector3(0.12f, 0.35f, 1f);
        handle.GetComponent<MeshRenderer>().sharedMaterial = handleMat;
        Destroy(handle.GetComponent<MeshCollider>());

        // ── Flamme (billboard) ─────────────────────────────────────────────
        var flame = GameObject.CreatePrimitive(PrimitiveType.Quad);
        flame.name = "Flame";
        flame.transform.SetParent(torchGO.transform);
        flame.transform.localPosition = new Vector3(0f, 0.28f, 0f);
        flame.transform.localRotation = Quaternion.identity;
        flame.transform.localScale    = new Vector3(0.25f, 0.38f, 1f);
        // Chaque flamme a son propre Material (pour PropertyBlock indépendant)
        flame.GetComponent<MeshRenderer>().material = new Material(flameMat);
        Destroy(flame.GetComponent<MeshCollider>());

        // ── Lumière ────────────────────────────────────────────────────────
        var lightGO = new GameObject("FlameLight");
        lightGO.transform.SetParent(torchGO.transform);
        lightGO.transform.localPosition = new Vector3(0f, 0.35f, 0.1f);
        var pointLight  = lightGO.AddComponent<Light>();
        pointLight.type = LightType.Point;

        // ── Controller ────────────────────────────────────────────────────
        torchGO.AddComponent<TorchController>();

        return torchGO;
    }

    // ─── Stats (debug) ────────────────────────────────────────────────────────
    public int ActiveCount => _active.Count;
    public int PooledCount => _pool.Count;
}
