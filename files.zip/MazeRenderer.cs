using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// MAZERENDERER — Construit la scène 3D, utilise le cache de textures et le pool de torches.
///
/// SETUP dans Unity :
///  1. Crée un GameObject vide nommé "MazeManager"
///  2. Attache : MazeGenerator + MazeRenderer + TorchPool
///  3. Assigne le Prefab joueur dans l'Inspector (optionnel)
///  4. Lance le jeu → labyrinthe généré automatiquement
///
/// CYCLE DE VIE DES RESSOURCES :
///  Génération  → PixelArtTextureFactory.Get*()    crée ou retourne le cache
///              → TorchPool.Get()                  réutilise ou crée les torches
///  Régénération→ PixelArtTextureFactory.ClearCache() libère les textures GPU
///              → TorchPool.ReleaseAll()            remet les torches en réserve
/// </summary>
[RequireComponent(typeof(MazeGenerator))]
[RequireComponent(typeof(TorchPool))]
public class MazeRenderer : MonoBehaviour
{
    // ─── Paramètres Inspector ─────────────────────────────────────────────────
    [Header("Dimensions des cellules")]
    [SerializeField] private float cellSize   = 4f;
    [SerializeField] private float wallHeight = 3f;

    [Header("Torches")]
    [SerializeField] private float torchProbability = 0.33f;
    [SerializeField] private float torchHeightRatio = 0.55f;

    [Header("Joueur")]
    [SerializeField] private GameObject playerPrefab;
    [SerializeField] private float      playerSpawnOffsetY = 1.5f;

    [Header("Ambiance")]
    [SerializeField] private Color ambientColor = new Color(0.04f, 0.03f, 0.02f);

    // ─── Composants ───────────────────────────────────────────────────────────
    private MazeGenerator _gen;
    private TorchPool     _torchPool;

    // ─── Matériaux (créés une fois, partagent les textures cachées) ───────────
    private Material _wallMat;
    private Material _floorMat;
    private Material _ceilMat;
    private Material _flameMat;
    private Material _handleMat;

    // ─── Containers de scène ──────────────────────────────────────────────────
    private Transform _mazeRoot;
    private Transform _torchRoot;

    // ─────────────────────────────────────────────────────────────────────────
    void Awake()
    {
        _gen       = GetComponent<MazeGenerator>();
        _torchPool = GetComponent<TorchPool>();
    }

    void Start() => BuildMaze();

    // ─────────────────────────────────────────────────────────────────────────
    //  CONSTRUCTION PRINCIPALE
    // ─────────────────────────────────────────────────────────────────────────

    public void BuildMaze()
    {
        CleanupOld();               // Libère l'ancienne géométrie + textures + torches
        SetupEnvironment();
        _gen.Generate();
        CreateMaterials();          // Récupère depuis le cache (ou crée si premier appel)
        CreateContainers();
        BuildGeometry();
        SpawnPlayer();

        Debug.Log($"[MazeRenderer] Labyrinthe construit. " +
                  $"Torches actives : {_torchPool.ActiveCount} | " +
                  $"En réserve : {_torchPool.PooledCount}");
    }

    public void Regenerate() => BuildMaze();

    // ─────────────────────────────────────────────────────────────────────────
    //  NETTOYAGE — libère géométrie, textures GPU et remet les torches en pool
    // ─────────────────────────────────────────────────────────────────────────

    private void CleanupOld()
    {
        // Géométrie
        if (_mazeRoot  != null) Destroy(_mazeRoot.gameObject);
        if (_torchRoot != null) Destroy(_torchRoot.gameObject);

        // Torches → retour dans le pool (pas de destruction)
        _torchPool.ReleaseAll();

        // Matériaux de l'ancienne génération
        SafeDestroyMat(ref _wallMat);
        SafeDestroyMat(ref _floorMat);
        SafeDestroyMat(ref _ceilMat);
        SafeDestroyMat(ref _flameMat);
        SafeDestroyMat(ref _handleMat);

        // Textures GPU → cache libéré, sera recréé à la prochaine demande
        PixelArtTextureFactory.ClearCache();
    }

    private void SafeDestroyMat(ref Material mat)
    {
        if (mat != null) { Destroy(mat); mat = null; }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  MATÉRIAUX — pointent vers les textures du cache
    // ─────────────────────────────────────────────────────────────────────────

    private void CreateMaterials()
    {
        _wallMat   = MakePixelMat(PixelArtTextureFactory.GetWallTexture(),    cellSize / 2f, wallHeight / 2f);
        _floorMat  = MakePixelMat(PixelArtTextureFactory.GetFloorTexture(),   1f, 1f);
        _ceilMat   = MakePixelMat(PixelArtTextureFactory.GetCeilingTexture(), 1f, 1f);
        _handleMat = MakePixelMat(PixelArtTextureFactory.GetTorchHandleTexture(), 1f, 1f);
        _flameMat  = MakeTransparentMat(PixelArtTextureFactory.GetFlameFrames()[0]);
    }

    private Material MakePixelMat(Texture2D tex, float tilingX, float tilingY)
    {
        var mat = new Material(Shader.Find("Universal Render Pipeline/Lit"));
        if (mat.shader.name.Contains("Error"))
            mat = new Material(Shader.Find("Standard"));

        mat.mainTexture      = tex;
        mat.mainTextureScale = new Vector2(tilingX, tilingY);
        mat.SetFloat("_Smoothness", 0f);
        mat.SetFloat("_Metallic",   0f);
        return mat;
    }

    private Material MakeTransparentMat(Texture2D tex)
    {
        var mat = new Material(Shader.Find("Universal Render Pipeline/Unlit"));
        if (mat.shader.name.Contains("Error"))
            mat = new Material(Shader.Find("Unlit/Transparent"));
        else
            mat.SetFloat("_Surface", 1f);

        mat.mainTexture = tex;
        mat.renderQueue = 3000;
        return mat;
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  CONTAINERS DE SCÈNE
    // ─────────────────────────────────────────────────────────────────────────

    private void CreateContainers()
    {
        _mazeRoot  = new GameObject("MazeGeometry").transform;
        _torchRoot = new GameObject("Torches").transform;
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  CONSTRUCTION DES QUADS
    // ─────────────────────────────────────────────────────────────────────────

    private void BuildGeometry()
    {
        var wallFaces = new List<(Vector3 pos, Quaternion rot)>();

        for (int x = 0; x < _gen.Width;  x++)
        for (int y = 0; y < _gen.Height; y++)
        {
            float cx = (x + 0.5f) * cellSize;
            float cz = (y + 0.5f) * cellSize;
            float wx = x * cellSize;
            float wz = y * cellSize;

            // Sol et plafond
            MakeQuad(new Vector3(cx, 0f,          cz), Quaternion.Euler( 90f,0f,0f), cellSize, cellSize, _floorMat, $"Fl_{x}_{y}");
            MakeQuad(new Vector3(cx, wallHeight,   cz), Quaternion.Euler(-90f,0f,0f), cellSize, cellSize, _ceilMat,  $"Ce_{x}_{y}");

            // Murs
            if (_gen.HasWall(x,y,MazeGenerator.Wall.North)) { var p=new Vector3(cx,wallHeight*.5f,wz+cellSize); var r=Quaternion.Euler(0f,180f,0f);    MakeWall(p,r,$"WN_{x}_{y}"); wallFaces.Add((p,r)); }
            if (_gen.HasWall(x,y,MazeGenerator.Wall.South)) { var p=new Vector3(cx,wallHeight*.5f,wz);          var r=Quaternion.identity;              MakeWall(p,r,$"WS_{x}_{y}"); wallFaces.Add((p,r)); }
            if (_gen.HasWall(x,y,MazeGenerator.Wall.East))  { var p=new Vector3(wx+cellSize,wallHeight*.5f,cz); var r=Quaternion.Euler(0f,-90f,0f);    MakeWall(p,r,$"WE_{x}_{y}"); wallFaces.Add((p,r)); }
            if (_gen.HasWall(x,y,MazeGenerator.Wall.West))  { var p=new Vector3(wx,wallHeight*.5f,cz);          var r=Quaternion.Euler(0f, 90f,0f);    MakeWall(p,r,$"WW_{x}_{y}"); wallFaces.Add((p,r)); }
        }

        PlaceTorches(wallFaces);
    }

    private void MakeWall(Vector3 pos, Quaternion rot, string name)
    {
        var go = MakeQuad(pos, rot, cellSize, wallHeight, _wallMat, name);
        Destroy(go.GetComponent<MeshCollider>());
        var b = go.AddComponent<BoxCollider>();
        b.size = new Vector3(1f, 1f, 0.05f);
    }

    private GameObject MakeQuad(Vector3 pos, Quaternion rot, float w, float h, Material mat, string name)
    {
        var go = GameObject.CreatePrimitive(PrimitiveType.Quad);
        go.name = name;
        go.transform.SetParent(_mazeRoot);
        go.transform.SetPositionAndRotation(pos, rot);
        go.transform.localScale = new Vector3(w, h, 1f);
        go.GetComponent<MeshRenderer>().sharedMaterial = mat;
        go.isStatic = true;
        return go;
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  PLACEMENT DES TORCHES (via pool)
    // ─────────────────────────────────────────────────────────────────────────

    private void PlaceTorches(List<(Vector3 pos, Quaternion rot)> wallFaces)
    {
        // Mélange aléatoire
        for (int i = wallFaces.Count - 1; i > 0; i--)
        {
            int j = Random.Range(0, i + 1);
            (wallFaces[i], wallFaces[j]) = (wallFaces[j], wallFaces[i]);
        }

        var placed   = new List<Vector3>();
        float minDist = cellSize * 1.5f;
        var frames   = PixelArtTextureFactory.GetFlameFrames();

        foreach (var (wallPos, wallRot) in wallFaces)
        {
            if (Random.value > torchProbability) continue;

            bool tooClose = false;
            foreach (var p in placed)
                if (Vector3.Distance(wallPos, p) < minDist) { tooClose = true; break; }
            if (tooClose) continue;

            Vector3 inward   = wallRot * Vector3.forward;
            float   torchY   = torchHeightRatio * wallHeight;
            Vector3 torchPos = new Vector3(wallPos.x, torchY, wallPos.z) + inward * 0.12f;

            // Récupère depuis le pool (ou crée si pool vide)
            _torchPool.Get(torchPos, wallRot, _torchRoot, frames, _flameMat, _handleMat);
            placed.Add(wallPos);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  ENVIRONNEMENT
    // ─────────────────────────────────────────────────────────────────────────

    private void SetupEnvironment()
    {
        RenderSettings.ambientMode      = UnityEngine.Rendering.AmbientMode.Flat;
        RenderSettings.ambientLight     = ambientColor;
        RenderSettings.fog              = true;
        RenderSettings.fogMode          = FogMode.Linear;
        RenderSettings.fogColor         = new Color(0.02f, 0.01f, 0.01f);
        RenderSettings.fogStartDistance = cellSize * 3f;
        RenderSettings.fogEndDistance   = cellSize * 8f;
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  SPAWN JOUEUR
    // ─────────────────────────────────────────────────────────────────────────

    private void SpawnPlayer()
    {
        Vector3 spawnPos = new Vector3(
            (_gen.StartCell.x + 0.5f) * cellSize,
            playerSpawnOffsetY,
            (_gen.StartCell.y + 0.5f) * cellSize);

        if (playerPrefab != null)
            Instantiate(playerPrefab, spawnPos, Quaternion.identity);
        else
        {
            var player = FindFirstObjectByType<PlayerController>();
            if (player != null) player.transform.position = spawnPos;
            else Debug.LogWarning("[MazeRenderer] Aucun joueur trouvé ! Assigne playerPrefab.");
        }
    }

#if UNITY_EDITOR
    [UnityEditor.MenuItem("Maze/Regenerate")]
    static void RegenerateMenu() => FindFirstObjectByType<MazeRenderer>()?.Regenerate();
#endif
}
