using UnityEngine;

/// <summary>
/// PIXELARTEXTUREFACTORY — Génère et met en CACHE toutes les textures pixel art.
///
/// FONCTIONNEMENT DU CACHE :
///  - Les textures sont créées UNE SEULE FOIS et réutilisées pour tout le labyrinthe.
///  - Apply(false, true) libère la RAM CPU après upload GPU.
///  - Appeler ClearCache() avant chaque nouvelle génération de labyrinthe
///    pour détruire les textures GPU et forcer la recréation.
/// </summary>
public static class PixelArtTextureFactory
{
    // ─── Cache statique ───────────────────────────────────────────────────────
    private static Texture2D   _wallTex;
    private static Texture2D   _floorTex;
    private static Texture2D   _ceilTex;
    private static Texture2D   _handleTex;
    private static Texture2D[] _flameFrames;

    // ─── Palettes ─────────────────────────────────────────────────────────────
    static readonly Color32 WallMortar    = new Color32(28, 26, 24, 255);
    static readonly Color32 WallDark      = new Color32(55, 50, 45, 255);
    static readonly Color32 WallMid       = new Color32(75, 68, 60, 255);
    static readonly Color32 WallLight     = new Color32(95, 86, 76, 255);
    static readonly Color32 WallHighlight = new Color32(112,101,89, 255);
    static readonly Color32 FloorDark     = new Color32(30, 26, 20, 255);
    static readonly Color32 FloorMid      = new Color32(48, 42, 32, 255);
    static readonly Color32 FloorLight    = new Color32(62, 55, 42, 255);
    static readonly Color32 FloorCrack    = new Color32(20, 18, 14, 255);
    static readonly Color32 CeilDark      = new Color32(14, 13, 12, 255);
    static readonly Color32 CeilMid       = new Color32(22, 20, 18, 255);
    static readonly Color32 CeilLight     = new Color32(32, 29, 26, 255);

    // ─────────────────────────────────────────────────────────────────────────
    //  ACCESSEURS — retourne le cache ou crée si absent
    // ─────────────────────────────────────────────────────────────────────────

    public static Texture2D GetWallTexture()
    {
        if (_wallTex == null) _wallTex = BuildWallTexture();
        return _wallTex;
    }

    public static Texture2D GetFloorTexture()
    {
        if (_floorTex == null) _floorTex = BuildFloorTexture();
        return _floorTex;
    }

    public static Texture2D GetCeilingTexture()
    {
        if (_ceilTex == null) _ceilTex = BuildCeilingTexture();
        return _ceilTex;
    }

    public static Texture2D GetTorchHandleTexture()
    {
        if (_handleTex == null) _handleTex = BuildTorchHandleTexture();
        return _handleTex;
    }

    public static Texture2D[] GetFlameFrames()
    {
        if (_flameFrames == null)
        {
            _flameFrames = new Texture2D[4];
            for (int i = 0; i < 4; i++)
                _flameFrames[i] = BuildFlameFrame(i);
        }
        return _flameFrames;
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  LIBÉRATION DU CACHE
    //  Appeler AVANT chaque nouvelle génération de labyrinthe.
    // ─────────────────────────────────────────────────────────────────────────

    public static void ClearCache()
    {
        SafeDestroy(ref _wallTex);
        SafeDestroy(ref _floorTex);
        SafeDestroy(ref _ceilTex);
        SafeDestroy(ref _handleTex);

        if (_flameFrames != null)
        {
            for (int i = 0; i < _flameFrames.Length; i++)
                SafeDestroy(ref _flameFrames[i]);
            _flameFrames = null;
        }

        Debug.Log("[TextureCache] Textures libérées de la mémoire GPU.");
    }

    private static void SafeDestroy(ref Texture2D tex)
    {
        if (tex != null) { Object.Destroy(tex); tex = null; }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  BUILDERS INTERNES
    // ─────────────────────────────────────────────────────────────────────────

    private static Texture2D BuildWallTexture()
    {
        int size = 32;
        var px   = new Color32[size * size];
        for (int i = 0; i < px.Length; i++) px[i] = WallMid;

        int brickH = 8, brickW = 16;
        for (int y = 0; y < size; y++)
        {
            int row    = y / brickH;
            int offset = (row % 2 == 0) ? 0 : brickW / 2;

            if (y % brickH == 0)
            {
                for (int x = 0; x < size; x++) px[y * size + x] = WallMortar;
                continue;
            }

            for (int x = 0; x < size; x++)
            {
                int brickX = (x + offset) % brickW;
                if (brickX == 0) { px[y * size + x] = WallMortar; continue; }

                int noise = ((row * 7 + (x + offset) / brickW * 13) % 4);
                px[y * size + x] = noise switch { 0 => WallDark, 1 => WallMid, 2 => WallLight, _ => WallHighlight };

                if (y % brickH == 1 && brickX > 1) px[y * size + x] = Brighten(px[y * size + x], 18);
                if (y % brickH == brickH - 1)       px[y * size + x] = Darken(px[y * size + x], 18);
            }
        }
        return Finalize(NewTex(size, size, TextureWrapMode.Repeat), px);
    }

    private static Texture2D BuildFloorTexture()
    {
        int size     = 32;
        int tileSize = 16;
        var px       = new Color32[size * size];
        for (int i = 0; i < px.Length; i++) px[i] = FloorMid;

        for (int y = 0; y < size; y++)
        for (int x = 0; x < size; x++)
        {
            int tx = x % tileSize, ty = y % tileSize;
            if (tx == 0 || ty == 0) { px[y * size + x] = FloorCrack; continue; }

            int tileId = (x / tileSize) + (y / tileSize) * (size / tileSize);
            int noise  = (tileId * 17 + tx * 3 + ty * 5) % 5;
            px[y * size + x] = noise switch { 0 => FloorDark, 1 => FloorDark, 3 => FloorLight, _ => FloorMid };

            if ((tileId * 11 + tx * 7) % 29 == 0) px[y * size + x] = FloorCrack;
            if (tx == 1 && ty > 1)                 px[y * size + x] = Brighten(px[y * size + x], 12);
        }
        return Finalize(NewTex(size, size, TextureWrapMode.Repeat), px);
    }

    private static Texture2D BuildCeilingTexture()
    {
        int size = 32;
        var px   = new Color32[size * size];
        for (int i = 0; i < px.Length; i++) px[i] = CeilMid;

        for (int y = 0; y < size; y++)
        for (int x = 0; x < size; x++)
        {
            int noise = (x * 3 + y * 7 + x * y) % 7;
            px[y * size + x] = noise switch { 0 => CeilDark, 1 => CeilDark, 5 => CeilLight, _ => CeilMid };
            if ((x * 13 + y * 11) % 37 == 0) px[y * size + x] = CeilDark;
        }
        return Finalize(NewTex(size, size, TextureWrapMode.Repeat), px);
    }

    private static Texture2D BuildTorchHandleTexture()
    {
        int w = 8, h = 24;
        var px = new Color32[w * h];
        for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++)
            px[y * w + x] = (x == 0 || x == w - 1)
                ? new Color32(20, 18, 15, 255)
                : new Color32(55, 45, 35, 255);
        return Finalize(NewTex(w, h, TextureWrapMode.Clamp), px);
    }

    private static Texture2D BuildFlameFrame(int frame)
    {
        int w = 16, h = 24;
        var px = new Color32[w * h];
        for (int i = 0; i < px.Length; i++) px[i] = Color.clear;

        int[] heights = frame switch
        {
            0 => new[] { 0,4,8,12,14,14,12,8,4,2,0,0,0,0,0,0 },
            1 => new[] { 0,2,6,10,14,16,14,10,6,4,2,0,0,0,0,0 },
            2 => new[] { 0,0,4,8,12,16,18,14,8,4,2,0,0,0,0,0 },
            _ => new[] { 0,2,8,12,14,14,12,8,6,2,0,0,0,0,0,0 }
        };
        int shift = frame switch { 1 => 1, 2 => 2, 3 => -1, _ => 0 };

        for (int x = 0; x < w; x++)
        {
            int sx   = Mathf.Clamp(x - shift, 0, w - 1);
            int maxH = heights[sx];
            for (int y = 0; y < maxH && y < h; y++)
            {
                float t = (float)y / maxH;
                px[y * w + x] = t switch
                {
                    < 0.15f => new Color32(180, 30,  0,   255),
                    < 0.35f => new Color32(220, 80,  0,   255),
                    < 0.55f => new Color32(255, 140, 0,   255),
                    < 0.72f => new Color32(255, 210, 20,  255),
                    < 0.87f => new Color32(255, 240, 100, 255),
                    _       => new Color32(255, 255, 200, 200)
                };
            }
        }
        for (int x = 2; x < w - 2; x++)
        {
            px[0 * w + x] = new Color32(200, 60, 0, 255);
            px[1 * w + x] = new Color32(220, 90, 0, 255);
        }
        return Finalize(NewTex(w, h, TextureWrapMode.Clamp), px);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  HELPERS
    // ─────────────────────────────────────────────────────────────────────────

    private static Texture2D NewTex(int w, int h, TextureWrapMode wrap)
        => new Texture2D(w, h, TextureFormat.RGBA32, false)
           { filterMode = FilterMode.Point, wrapMode = wrap, anisoLevel = 0 };

    /// <summary>Upload GPU + libère la RAM CPU (makeNoLongerReadable = true).</summary>
    private static Texture2D Finalize(Texture2D tex, Color32[] px)
    {
        tex.SetPixels32(px);
        tex.Apply(false, true);
        return tex;
    }

    private static Color32 Darken(Color32 c, int a)
        => new Color32((byte)Mathf.Max(0,c.r-a),(byte)Mathf.Max(0,c.g-a),(byte)Mathf.Max(0,c.b-a),c.a);

    private static Color32 Brighten(Color32 c, int a)
        => new Color32((byte)Mathf.Min(255,c.r+a),(byte)Mathf.Min(255,c.g+a),(byte)Mathf.Min(255,c.b+a),c.a);
}
