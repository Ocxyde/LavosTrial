using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// MAZEGENERATOR — Génère les données du labyrinthe (algorithme DFS Recursive Backtracker)
/// Ne touche pas à la scène, produit uniquement une grille de données.
///
/// SETUP : Attache sur le même GameObject que MazeRenderer.
/// </summary>
public class MazeGenerator : MonoBehaviour
{
    // ─── Masques de murs par cellule (bitfield) ───────────────────────────────
    [System.Flags]
    public enum Wall : byte
    {
        None  = 0,
        North = 1,   // +Z
        East  = 2,   // +X
        South = 4,   // -Z
        West  = 8,   // -X
        All   = North | East | South | West
    }

    // ─── Paramètres Inspector ─────────────────────────────────────────────────
    [Header("Dimensions du labyrinthe")]
    [SerializeField] public int mazeWidth  = 19;
    [SerializeField] public int mazeHeight = 19;

    [Header("Graine aléatoire (0 = aléatoire à chaque fois)")]
    [SerializeField] private int seed = 0;

    // ─── Données publiques ────────────────────────────────────────────────────
    public Wall[,]    Grid       { get; private set; }
    public int        Width      => mazeWidth;
    public int        Height     => mazeHeight;
    public Vector2Int StartCell  { get; private set; }
    public Vector2Int ExitCell   { get; private set; }

    // ─────────────────────────────────────────────────────────────────────────
    /// <summary>Lance la génération. Appeler avant MazeRenderer.Build().</summary>
    public void Generate()
    {
        if (seed != 0)
            Random.InitState(seed);

        Grid = new Wall[mazeWidth, mazeHeight];

        // Toutes les cellules commencent avec leurs 4 murs
        for (int x = 0; x < mazeWidth;  x++)
        for (int y = 0; y < mazeHeight; y++)
            Grid[x, y] = Wall.All;

        // ── DFS Recursive Backtracker ──────────────────────────────────────
        bool[,]             visited = new bool[mazeWidth, mazeHeight];
        Stack<Vector2Int>   stack   = new Stack<Vector2Int>();

        StartCell = new Vector2Int(0, 0);
        visited[0, 0] = true;
        stack.Push(StartCell);

        while (stack.Count > 0)
        {
            Vector2Int current   = stack.Peek();
            var        neighbors = GetUnvisitedNeighbors(current, visited);

            if (neighbors.Count > 0)
            {
                Vector2Int next = neighbors[Random.Range(0, neighbors.Count)];
                CarveWall(current, next);
                visited[next.x, next.y] = true;
                stack.Push(next);
            }
            else
            {
                stack.Pop();
            }
        }

        // Sortie = coin opposé à l'entrée
        ExitCell = new Vector2Int(mazeWidth - 1, mazeHeight - 1);

        // Ouvre les passages d'entrée et sortie
        Grid[StartCell.x, StartCell.y] &= ~Wall.South;
        Grid[ExitCell.x,  ExitCell.y]  &= ~Wall.North;

        Debug.Log($"[MazeGenerator] Labyrinthe {mazeWidth}x{mazeHeight} généré. Seed={seed}");
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  HELPERS
    // ─────────────────────────────────────────────────────────────────────────

    private List<Vector2Int> GetUnvisitedNeighbors(Vector2Int cell, bool[,] visited)
    {
        var result = new List<Vector2Int>(4);
        var dirs   = new[] { Vector2Int.up, Vector2Int.right, Vector2Int.down, Vector2Int.left };

        foreach (var d in dirs)
        {
            var n = cell + d;
            if (n.x >= 0 && n.x < mazeWidth &&
                n.y >= 0 && n.y < mazeHeight &&
                !visited[n.x, n.y])
                result.Add(n);
        }
        return result;
    }

    private void CarveWall(Vector2Int a, Vector2Int b)
    {
        Vector2Int diff = b - a;

        if      (diff == Vector2Int.up)    { Grid[a.x,a.y] &= ~Wall.North; Grid[b.x,b.y] &= ~Wall.South; }
        else if (diff == Vector2Int.right) { Grid[a.x,a.y] &= ~Wall.East;  Grid[b.x,b.y] &= ~Wall.West;  }
        else if (diff == Vector2Int.down)  { Grid[a.x,a.y] &= ~Wall.South; Grid[b.x,b.y] &= ~Wall.North; }
        else if (diff == Vector2Int.left)  { Grid[a.x,a.y] &= ~Wall.West;  Grid[b.x,b.y] &= ~Wall.East;  }
    }

    // ─────────────────────────────────────────────────────────────────────────
    /// <summary>Retourne true si la cellule (x,y) a le mur indiqué.</summary>
    public bool HasWall(int x, int y, Wall wall) => (Grid[x, y] & wall) != 0;
}
