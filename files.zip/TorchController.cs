using UnityEngine;

/// <summary>
/// TORCHCONTROLLER — Torche avec flamme animée pixel art et lumière vacillante.
///
/// Créé automatiquement par MazeRenderer. Pas besoin de setup manuel.
///
/// Structure du GameObject torche :
///   Torch_X_Y
///   ├── Handle         (quad — le bâton de la torche)
///   ├── Flame          (quad billboard — la flamme animée)
///   └── FlameLight     (PointLight — lumière vacillante orange)
/// </summary>
public class TorchController : MonoBehaviour
{
    // ─── Paramètres Inspector ─────────────────────────────────────────────────
    [Header("Animation flamme")]
    [SerializeField] private float frameRate    = 8f;   // Frames par seconde
    [SerializeField] private float bobAmplitude = 0.04f;
    [SerializeField] private float bobSpeed     = 3f;

    [Header("Lumière")]
    [SerializeField] private float lightBaseIntensity = 1.8f;
    [SerializeField] private float lightFlickerAmount = 0.5f;
    [SerializeField] private float lightFlickerSpeed  = 12f;
    [SerializeField] private float lightRange         = 7f;
    [SerializeField] private Color lightColor         = new Color(1f, 0.55f, 0.1f);

    // ─── Références internes ──────────────────────────────────────────────────
    private Renderer     _flameRenderer;
    private Light        _light;
    private Transform    _flameTransform;
    private Texture2D[]  _frames;
    private MaterialPropertyBlock _mpb;

    // ─── État ─────────────────────────────────────────────────────────────────
    private int   _currentFrame  = 0;
    private float _frameTimer    = 0f;
    private float _flickerOffset;
    private Vector3 _flameBaseLocalPos;

    // ─────────────────────────────────────────────────────────────────────────
    /// <summary>Initialise la torche avec les frames de flamme fournies.</summary>
    public void Initialize(Texture2D[] flameFrames, Renderer flameRenderer, Light pointLight)
    {
        _frames        = flameFrames;
        _flameRenderer = flameRenderer;
        _light         = pointLight;
        _flameTransform = flameRenderer.transform;
        _flameBaseLocalPos = _flameTransform.localPosition;
        _flickerOffset = Random.Range(0f, 100f); // Décalage pour que chaque torche soit différente
        _mpb           = new MaterialPropertyBlock();

        // Applique la première frame
        SetFrame(0);

        // Configure la lumière
        if (_light != null)
        {
            _light.color     = lightColor;
            _light.range     = lightRange;
            _light.intensity = lightBaseIntensity;
            _light.shadows   = LightShadows.Soft;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    void Update()
    {
        if (_frames == null || _frames.Length == 0) return;

        AnimateFlame();
        FlickerLight();
        BillboardFlame();
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  ANIMATION FLAMME
    // ─────────────────────────────────────────────────────────────────────────
    private void AnimateFlame()
    {
        _frameTimer += Time.deltaTime;

        if (_frameTimer >= 1f / frameRate)
        {
            _frameTimer   = 0f;
            _currentFrame = (_currentFrame + 1) % _frames.Length;
            SetFrame(_currentFrame);
        }

        // Légère oscillation verticale de la flamme
        float bob = Mathf.Sin(Time.time * bobSpeed + _flickerOffset) * bobAmplitude;
        _flameTransform.localPosition = _flameBaseLocalPos + new Vector3(0f, bob, 0f);
    }

    private void SetFrame(int frame)
    {
        if (_flameRenderer == null) return;
        _flameRenderer.GetPropertyBlock(_mpb);
        _mpb.SetTexture("_MainTex", _frames[frame]);
        _flameRenderer.SetPropertyBlock(_mpb);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  VACILLEMENT DE LA LUMIÈRE
    // ─────────────────────────────────────────────────────────────────────────
    private void FlickerLight()
    {
        if (_light == null) return;

        // Combine plusieurs fréquences pour un vacillement naturel
        float flicker = Mathf.PerlinNoise(Time.time * lightFlickerSpeed + _flickerOffset, 0f);
        flicker += Mathf.PerlinNoise(Time.time * lightFlickerSpeed * 0.4f + _flickerOffset + 5f, 0f) * 0.5f;
        flicker /= 1.5f;

        _light.intensity = lightBaseIntensity + (flicker - 0.5f) * lightFlickerAmount;
        _light.intensity = Mathf.Max(0.3f, _light.intensity);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  BILLBOARD — La flamme fait toujours face à la caméra
    // ─────────────────────────────────────────────────────────────────────────
    private void BillboardFlame()
    {
        if (Camera.main == null) return;

        Vector3 dir = Camera.main.transform.position - _flameTransform.position;
        dir.y = 0f; // Ne s'incline pas vers le haut/bas
        if (dir.sqrMagnitude < 0.001f) return;

        _flameTransform.rotation = Quaternion.LookRotation(-dir.normalized, Vector3.up);
    }
}
