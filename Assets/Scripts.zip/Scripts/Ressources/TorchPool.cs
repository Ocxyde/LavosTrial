using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// TORCHPOOL — Pool d'objets pour les torches.
///
/// FONCTIONNEMENT :
///  - Les GameObjects de torche sont créés une fois puis désactivés (pas détruits).
///  - À la régénération, ils sont réactivés et repositionnés → zéro allocation.
///  - Si le nouveau labyrinthe a besoin de plus de torches que le pool,
///    il crée les manquantes et les ajoute au pool.
///  - ReleaseAll() remet toutes les torches en réserve sans les détruire.
///
/// SETUP : Attache sur le même GameObject que MazeRenderer.
/// </summary>
public class TorchPool : MonoBehaviour
{
    // ─── Pool ─────────────────────────────────────────────────────────────────
    private readonly List<GameObject>      _pool   = new List<GameObject>();
    private readonly List<TorchController> _active = new List<TorchController>();
    private Transform                      _poolRoot;

    // ─── Matériaux partagés (évite les allocations à chaque torche) ───────────
    private Material _sharedFlameMat;
    private Material _sharedHandleMat;

    // ─── Brasero Flame ──────────────────────────────────────────────────────
    [SerializeField] private bool useBraseroFlame = true;

    // ─────────────────────────────────────────────────────────────────────────
    void Awake()
    {
        _poolRoot = new GameObject("TorchPool_Inactive").transform;
        _poolRoot.SetParent(transform);
        _poolRoot.gameObject.SetActive(false); // Cache tout le conteneur
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  RÉCUPÉRER UNE TORCHE (depuis le pool ou nouvelle création)
    // ─────────────────────────────────────────────────────────────────────────

    /// <summary>
    /// Retourne une torche prête à l'emploi, repositionnée et réinitialisée.
    /// </summary>
    public TorchController Get(Vector3 position, Quaternion rotation,
                               Transform activeParent, Texture2D[] flameFrames,
                               Material flameMat, Material handleMat)
    {
        // Stocke les matériaux partagés (crée une seule instance)
        if (flameMat != null && _sharedFlameMat == null)
            _sharedFlameMat = new Material(flameMat);
        else if (_sharedFlameMat == null && flameFrames != null && flameFrames.Length > 0 && flameFrames[0] != null)
        {
            // Fallback: créer un matériau basique si flameMat est null
            Debug.LogWarning("[TorchPool] Flame material is null, creating fallback material");
            var fallbackShader = Shader.Find("Sprites/Default") ?? Shader.Find("Unlit/Transparent");
            if (fallbackShader != null)
            {
                _sharedFlameMat = new Material(fallbackShader);
                _sharedFlameMat.mainTexture = flameFrames[0];
            }
        }
        
        if (handleMat != null && _sharedHandleMat == null)
            _sharedHandleMat = new Material(handleMat);

        GameObject go;

        if (_pool.Count > 0)
        {
            // Réutilise depuis le pool
            go = _pool[_pool.Count - 1];
            _pool.RemoveAt(_pool.Count - 1);
        }
        else
        {
            // Crée une nouvelle torche et l'ajoute au pool pour la prochaine fois
            go = BuildTorchObject();
        }

        // Repositionne et rattache au parent actif
        go.transform.SetParent(activeParent);
        go.transform.position = position;
        go.transform.rotation = rotation;
        go.SetActive(true);

        // Réinitialise le controller
        var ctrl = go.GetComponent<TorchController>();
        var flameMR = go.transform.Find("Flame")?.GetComponent<Renderer>();
        var light = go.transform.Find("FlameLight")?.GetComponent<Light>();

        // Defensive: if components are missing, fall back to sprite mode to avoid runtime errors
        if (ctrl == null)
        {
            Debug.LogWarning("[TorchPool] TorchController missing on rebuilt torch. Skipping initialization.");
        }

        if (useBraseroFlame)
        {
            var braseroFlame = go.transform.Find("BraseroFlame")?.GetComponent<BraseroFlame>();
            if (braseroFlame != null && ctrl != null && light != null)
            {
                ctrl.InitializeBrasero(light, braseroFlame);
            }
            else
            {
                Debug.LogWarning("[TorchPool] BraseroFlame setup incomplete, falling back to sprite mode");
                SetupSpriteMode(go, flameFrames, flameMR, light, ctrl);
            }
        }
        else
        {
            SetupSpriteMode(go, flameFrames, flameMR, light, ctrl);
        }

        _active.Add(ctrl);
        return ctrl;
    }

    private void SetupSpriteMode(GameObject go, Texture2D[] flameFrames, Renderer flameMR, Light light, TorchController ctrl)
    {
        if (ctrl == null)
        {
            Debug.LogError("[TorchPool] TorchController component missing!");
            return;
        }

        ctrl.Initialize(flameFrames, flameMR, light);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  LIBÉRER TOUTES LES TORCHES ACTIVES → retour dans le pool
    // ─────────────────────────────────────────────────────────────────────────

    /// <summary>
    /// Désactive toutes les torches actives et les remet en réserve.
    /// Appeler avant chaque régénération de labyrinthe.
    /// </summary>
    public void ReleaseAll()
    {
        foreach (var ctrl in _active)
        {
            if (ctrl == null) continue;
            var go = ctrl.gameObject;
            go.SetActive(false);
            go.transform.SetParent(_poolRoot);
            _pool.Add(go);
        }
        _active.Clear();
        Debug.Log($"[TorchPool] {_pool.Count} torche(s) remise(s) en réserve.");
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  DESTRUCTION COMPLÈTE (fin de session)
    // ─────────────────────────────────────────────────────────────────────────

    /// <summary>Détruit toutes les torches (pool + actives). Appeler à la fin du jeu.</summary>
    public void DestroyAll()
    {
        ReleaseAll();
        foreach (var go in _pool)
            if (go != null) Destroy(go);
        _pool.Clear();

        if (_sharedFlameMat != null) { Destroy(_sharedFlameMat); _sharedFlameMat = null; }
        if (_sharedHandleMat != null) { Destroy(_sharedHandleMat); _sharedHandleMat = null; }
    }

    void OnDestroy() => DestroyAll();

    // ─────────────────────────────────────────────────────────────────────────
    //  CONSTRUCTION D'UNE TORCHE (interne)
    // ─────────────────────────────────────────────────────────────────────────

    private GameObject BuildTorchObject()
    {
        var torchGO = new GameObject("Torch");

        // ── Support (bâton) ────────────────────────────────────────────────
        // Créer un cube étroit pour le bois
        var handle = GameObject.CreatePrimitive(PrimitiveType.Cube);
        handle.name = "Handle";
        handle.transform.SetParent(torchGO.transform);
        handle.transform.localPosition = new Vector3(0f, 0f, 0f);
        // Inclinaison de 25° vers l'intérieur (l'avant du mur)
        handle.transform.localRotation = Quaternion.Euler(25f, 0f, 0f);
        handle.transform.localScale    = new Vector3(0.08f, 0.35f, 0.08f);
        handle.GetComponent<MeshRenderer>().sharedMaterial = _sharedHandleMat;
        Destroy(handle.GetComponent<BoxCollider>());

        if (useBraseroFlame)
        {
            // ── Brasero Flame (Particle System) ────────────────────────────
            var flame = new GameObject("BraseroFlame");
            flame.transform.SetParent(torchGO.transform);
            flame.transform.localPosition = new Vector3(0f, 0.25f, 0.05f);
            flame.transform.localRotation = Quaternion.identity;
            
            var braseroFlame = flame.AddComponent<BraseroFlame>();
            
            // ── Lumière ────────────────────────────────────────────────────
            var lightGO = new GameObject("FlameLight");
            lightGO.transform.SetParent(torchGO.transform);
            lightGO.transform.localPosition = new Vector3(0f, 0.4f, 0.08f);
            
            var pointLight = lightGO.AddComponent<Light>();
            pointLight.type = LightType.Point;
            pointLight.range = 10f;
            pointLight.intensity = 2.5f;
            pointLight.color = new Color(1f, 0.6f, 0.3f);
            pointLight.shadows = LightShadows.None;
            
            // Add light flicker to the torch controller
            var ctrl = torchGO.AddComponent<TorchController>();
            ctrl.InitializeBrasero(lightGO.GetComponent<Light>(), braseroFlame);
        }
        else
        {
            // ── Flamme (billboard 2D pixel art) ────────────────────────────────
            var flame = GameObject.CreatePrimitive(PrimitiveType.Quad);
            flame.name = "Flame";
            flame.transform.SetParent(torchGO.transform);
            // Position au bout du bois, penchée aussi
            flame.transform.localPosition = new Vector3(0f, 0.22f, 0.06f);
            flame.transform.localRotation = Quaternion.Euler(25f, 0f, 0f);
            flame.transform.localScale    = new Vector3(0.3f, 0.45f, 1f);
            flame.GetComponent<MeshRenderer>().sharedMaterial = _sharedFlameMat;
            Destroy(flame.GetComponent<MeshCollider>());

            // ── Lumière ────────────────────────────────────────────────────
            var lightGO = new GameObject("FlameLight");
            lightGO.transform.SetParent(torchGO.transform);
            lightGO.transform.localPosition = new Vector3(0f, 0.3f, 0.08f);
            
            var pointLight = lightGO.AddComponent<Light>();
            pointLight.type = LightType.Point;
            pointLight.range = 10f;
            pointLight.intensity = 2.5f;
            pointLight.color = new Color(1f, 0.6f, 0.3f); // Orange chaud
            pointLight.shadows = LightShadows.None; // Désactive les ombres pour éviter le warning

            // ── Controller ────────────────────────────────────────────────────
            torchGO.AddComponent<TorchController>();
        }

        return torchGO;
    }

    // ─── Stats (debug) ────────────────────────────────────────────────────────
    public int ActiveCount => _active.Count;
    public int PooledCount => _pool.Count;
}
