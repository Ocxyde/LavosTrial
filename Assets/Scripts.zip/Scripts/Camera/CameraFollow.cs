using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>
/// CAMERAFOLLOW — Caméra TPS avec le nouveau Input System (Unity 6)
///
/// SETUP dans Unity :
///  1. Attache ce script sur ta Camera principale
///  2. Assigne le Transform de ton joueur dans "target"
///  3. Ajuste distance, hauteur et sensibilité dans l'Inspector
/// </summary>
public class CameraFollow : MonoBehaviour
{
    [Header("Cible")]
    [SerializeField] private Transform target;

    [Header("Position")]
    [SerializeField] private float distance  = 5f;
    [SerializeField] private float height    = 2f;
    [SerializeField] private float smoothing = 10f;

    [Header("Rotation à la souris")]
    [SerializeField] private float sensitivityX = 0.3f;
    [SerializeField] private float sensitivityY = 0.2f;
    [SerializeField] private float minYAngle    = -20f;
    [SerializeField] private float maxYAngle    =  60f;

    [Header("Collision")]
    [SerializeField] private LayerMask collisionMask;
    [SerializeField] private float     minDistance = 0.5f;

    // ─── Variables internes ───────────────────────────────────────────────────
    private float _rotationX = 0f;
    private float _rotationY = 0f;
    private Mouse _mouse;

    // ─────────────────────────────────────────────────────────────────────────
    void Start()
    {
        if (target == null)
        {
            Debug.LogWarning("[CameraFollow] Aucune cible assignée !");
            return;
        }

        _mouse = Mouse.current;
        Vector3 angles = transform.eulerAngles;
        _rotationX = angles.y;
        _rotationY = angles.x;
    }

    // LateUpdate : s'exécute après Update, idéal pour la caméra
    void LateUpdate()
    {
        if (target == null) return;

        if (_mouse == null) return;

        if (GameManager.Instance != null &&
            GameManager.Instance.CurrentState != GameManager.GameState.Playing)
            return;

        // Rotation souris (nouveau Input System)
        Vector2 delta = _mouse.delta.ReadValue();
        _rotationX += delta.x * sensitivityX;
        _rotationY -= delta.y * sensitivityY;
        _rotationY  = Mathf.Clamp(_rotationY, minYAngle, maxYAngle);

        Quaternion rotation    = Quaternion.Euler(_rotationY, _rotationX, 0f);
        Vector3    desiredPos  = target.position + rotation * new Vector3(0f, height, -distance);

        // Collision avec les murs
        float   actualDist = distance;
        Vector3 dir        = desiredPos - target.position;

        if (Physics.Raycast(target.position, dir.normalized, out RaycastHit hit,
                             distance, collisionMask))
        {
            actualDist = Mathf.Max(hit.distance - 0.2f, minDistance);
        }

        Vector3 finalPos = target.position + rotation * new Vector3(0f, height, -actualDist);

        transform.position = Vector3.Lerp(transform.position, finalPos, smoothing * Time.deltaTime);
        transform.LookAt(target.position + Vector3.up * height * 0.5f);
    }
}
