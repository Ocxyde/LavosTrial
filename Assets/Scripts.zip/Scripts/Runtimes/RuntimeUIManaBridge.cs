using UnityEngine;

// Runtime Mana bar bridge: wires Player Mana into the Runtime UI Mana bar.
public class RuntimeUIManaBridge : MonoBehaviour
{
    private bool _initialized = false;
    private const string ManaId = "Mana";

    void Awake()
    {
        EnsureManaBarExists();
        Debug.Log("[Startup] RuntimeUIManaBridge initialized; Mana bar ensured.");
        _initialized = true;
    }

    void Update()
    {
        if (!_initialized) return;
        float t = 0f;
        if (TryGetManaFromStats(out float current, out float max))
        {
            t = max > 0 ? current / max : 0f;
        }
        else
        {
            t = Mathf.Clamp01((Mathf.Sin(Time.time * 1.5f) * 0.5f) + 0.5f);
        }
        RuntimeUIManager.Instance?.UpdateStatus(ManaId, t);
        // Optional minimal log
        // Debug.Log("[RuntimeUIManaBridge] Mana updated: " + t);
    }

    private void EnsureManaBarExists()
    {
        if (RuntimeUIManager.Instance == null)
        {
            var go = new GameObject("RuntimeUIManager");
            go.AddComponent<RuntimeUIManager>();
        }
        if (RuntimeUIManager.Instance != null)
        {
            // Right edge, centered vertically
            float xOffset = -20f - Mathf.Round(Screen.width * 0.02f);
            var bar = RuntimeUIManager.Instance.CreateStatusBar(ManaId, new Vector2(xOffset, 0f), new Vector2(200, 20), Color.cyan);
            if (bar != null) Debug.Log("[RuntimeUIManaBridge] Mana bar created: Mana");
        }
        _initialized = true;
    }

    private bool TryGetManaFromStats(out float current, out float max)
    {
        current = 0f; max = 1f;
        var playerStats = UnityEngine.Object.FindFirstObjectByType<PlayerStats>();
        if (playerStats != null)
        {
            current = playerStats.CurrentMana;
            max = playerStats.MaxMana;
            return true;
        }
        return false;
    }
}
