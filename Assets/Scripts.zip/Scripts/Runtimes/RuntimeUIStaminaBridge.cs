using UnityEngine;

// Runtime Stamina bar bridge: wires Player Stamina into the Runtime UI Stamina bar.
public class RuntimeUIStaminaBridge : MonoBehaviour
{
    private bool _initialized = false;
    private const string StaminaId = "Stamina";

    void Awake()
    {
        EnsureStaminaBarExists();
        Debug.Log("[Startup] RuntimeUIStaminaBridge initialized; Stamina bar ensured.");
        _initialized = true;
    }

    void Update()
    {
        if (!_initialized) return;
        float t = 0f;
        if (TryGetStaminaFromStats(out float current, out float max))
        {
            t = max > 0 ? current / max : 0f;
        }
        else
        {
            t = Mathf.Clamp01((Mathf.Sin(Time.time * 1.2f) * 0.5f) + 0.5f);
        }
        RuntimeUIManager.Instance?.UpdateStatus(StaminaId, t);
        // Optional small log omitted to reduce clutter
    }

    private void EnsureStaminaBarExists()
    {
        if (RuntimeUIManager.Instance == null)
        {
            var go = new GameObject("RuntimeUIManager");
            go.AddComponent<RuntimeUIManager>();
        }
        if (RuntimeUIManager.Instance != null)
        {
            // Bottom-center: anchor to middle-bottom with a slight offset
            float xOffset = 0f; // centered horizontally
            float yOffset = 40f; // distance from bottom
            var bar = RuntimeUIManager.Instance.CreateStatusBar(StaminaId, new Vector2(xOffset, -yOffset), new Vector2(200, 20), Color.cyan);
            if (bar != null) Debug.Log("[RuntimeUIStaminaBridge] Stamina bar created: Stamina");
        }
        _initialized = true;
    }

    private bool TryGetStaminaFromStats(out float current, out float max)
    {
        current = 0f; max = 1f;
        var playerStats = UnityEngine.Object.FindFirstObjectByType<PlayerStats>();
        if (playerStats != null)
        {
            current = playerStats.CurrentStamina;
            max = playerStats.MaxStamina;
            return true;
        }
        return false;
    }
}
