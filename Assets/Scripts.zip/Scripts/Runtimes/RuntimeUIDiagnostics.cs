using UnityEngine;
using System.Collections.Generic;

// Lightweight diagnostics for runtime UI canvas and status bars
// Attach to a GameObject in a scene to dump the runtime UI structure on PlayStart
public class RuntimeUIDiagnostics : MonoBehaviour
{
    public bool verbose = false;

    void Start()
    {
        #if UNITY_EDITOR
        Debug.Log("[RuntimeUIDiagnostics] Dumping runtime UI state...");
        var canvas = UnityEngine.Object.FindFirstObjectByType<RuntimeUIManager>();
        #else
        // Diagnostics disabled in builds
        var canvas = default(RuntimeUIManager);
        #endif
        if (canvas == null)
        {
            #if UNITY_EDITOR
            Debug.Log("[RuntimeUIDiagnostics] RuntimeUIManager not found");
            #endif
        }
        else
        {
            #if UNITY_EDITOR
            Debug.Log($"[RuntimeUIDiagnostics] RuntimeUIManager present: {canvas.name}");
            DumpCanvasState();
            #else
            // In builds, avoid heavy diagnostics
            #endif
        }
    }

    void DumpCanvasState()
    {
        // Try to locate the runtime canvas under the manager's context
        var rtCanvas = UnityEngine.Object.FindFirstObjectByType<Canvas>();
        if (rtCanvas != null)
        {
            Debug.Log($"[RuntimeUIDiagnostics] Canvas: {rtCanvas.name} RenderMode={rtCanvas.renderMode}");
            foreach (Transform child in rtCanvas.transform)
            {
                Debug.Log($"[RuntimeUIDiagnostics] Child: {child.name} - Active={child.gameObject.activeSelf}");
            }
        }
        else
        {
            Debug.Log("[RuntimeUIDiagnostics] No runtime Canvas found in scene");
        }
    }
}
