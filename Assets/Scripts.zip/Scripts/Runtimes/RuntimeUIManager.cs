// Canonical RuntimeUIManager (moved into Assets/Scripts/Runtimes)
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class RuntimeUIManager : MonoBehaviour
{
    public static RuntimeUIManager Instance { get; private set; }
    private Canvas _canvas;
    private readonly Dictionary<string, StatusBar> _bars = new Dictionary<string, StatusBar>();

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(this.gameObject);
        CreateCanvasIfNeeded();
    }

    void CreateCanvasIfNeeded()
    {
        _canvas = FindFirstObjectByType<Canvas>();
        if (_canvas == null)
        {
            var go = new GameObject("RuntimeUI");
            _canvas = go.AddComponent<Canvas>();
            _canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            go.AddComponent<CanvasScaler>();
            go.AddComponent<GraphicRaycaster>();
        }
    }

    public StatusBar CreateStatusBar(string id, Vector2 anchoredPos, Vector2 size, Color barColor)
    {
        if (_canvas == null) CreateCanvasIfNeeded();
        if (_bars.ContainsKey(id)) return _bars[id];
        GameObject barGO = new GameObject($"StatusBar_{id}");
        barGO.transform.SetParent(_canvas.transform, false);
        RectTransform rt = barGO.AddComponent<RectTransform>();
        rt.anchoredPosition = anchoredPos;
        rt.sizeDelta = size;
        GameObject bg = new GameObject("Background");
        bg.transform.SetParent(barGO.transform, false);
        RectTransform brt = bg.AddComponent<RectTransform>();
        brt.anchorMin = Vector2.zero; brt.anchorMax = Vector2.one;
        brt.offsetMin = Vector2.zero; brt.offsetMax = Vector2.zero;
        Image bgImg = bg.AddComponent<Image>();
        bgImg.color = new Color(0,0,0,0.25f);
        GameObject fillGO = new GameObject("Fill");
        fillGO.transform.SetParent(barGO.transform, false);
        RectTransform frt = fillGO.AddComponent<RectTransform>();
        frt.anchorMin = Vector2.zero; frt.anchorMax = Vector2.one;
        frt.offsetMin = Vector2.zero; frt.offsetMax = Vector2.zero;
        Image fillImg = fillGO.AddComponent<Image>();
        fillImg.color = barColor;
        fillImg.type = Image.Type.Filled;
        fillImg.fillMethod = Image.FillMethod.Horizontal;
        StatusBar bar = barGO.AddComponent<StatusBar>();
        bar.fillImage = fillImg;
        _bars[id] = bar;
        return bar;
    }

    public void UpdateStatus(string id, float value)
    {
        if (_bars.TryGetValue(id, out var bar)) bar.SetValue(value);
    }
}
