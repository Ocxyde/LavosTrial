using UnityEngine;

// Runtime health bar bridge: wires Player HP into the Runtime UI Health bar.
// Placement: left edge of the screen, vertically centered.
public class RuntimeUIHealthBridge : MonoBehaviour
{
    private bool _initialized = false;
    private const string HealthId = "Health";

    void Awake()
    {
        // Ensure the health bar exists
        EnsureHealthBarExists();
        Debug.Log("[Startup] RuntimeUIHealthBridge initialized; Health bar ensured.");
    }

    void Start()
    {
        _initialized = true;
    }

    void Update()
    {
        if (!_initialized) return;
        float t = 0f;
        if (TryGetHealthFromStats(out float current, out float max))
        {
            t = max > 0 ? current / max : 0f;
        }
        else
        {
            // Optional: simple demo pulse if no PlayerStats available.
            t = (Mathf.Sin(Time.time * 2f) * 0.5f) + 0.5f;
        }
        RuntimeUIManager.Instance?.UpdateStatus(HealthId, Mathf.Clamp01(t));
        Debug.Log("[RuntimeUIHealthBridge] Health updated: " + t);
    }

    private void EnsureHealthBarExists()
    {
        if (RuntimeUIManager.Instance == null) 
        {
            // If UI manager isn't ready yet, try to create one via bootstrap if needed
            var go = new GameObject("RuntimeUIManager");
            go.AddComponent<RuntimeUIManager>();
        }
        // Create or reuse the Health bar with resolution-aware positioning
        if (RuntimeUIManager.Instance != null)
        {
            // Compute left-edge, resolution-aware anchor position
            // We anchor to the left edge with a vertical center reference (anchor 0,0.5)
            float xOffset = 20f + Mathf.Round(Screen.width * 0.02f); // scalable offset from left edge
            float yCenter = 0f; // anchored at mid-height with 0 offset since anchor is 0.5
            var bar = RuntimeUIManager.Instance.CreateStatusBar(
                HealthId,
                new Vector2(xOffset, yCenter),
                new Vector2(200, 20),
                Color.green);
            if (bar != null)
            {
                Debug.Log("[RuntimeUIHealthBridge] Health bar created: Health");
            }
        }
        _initialized = true;
    }

    private bool TryGetHealthFromStats(out float current, out float max)
    {
        current = 0f; max = 1f;
        var playerStats = UnityEngine.Object.FindFirstObjectByType<PlayerStats>();
        if (playerStats != null)
        {
            current = playerStats.CurrentHealth;
            max = playerStats.MaxHealth;
            return true;
        }
        return false;
    }
}
