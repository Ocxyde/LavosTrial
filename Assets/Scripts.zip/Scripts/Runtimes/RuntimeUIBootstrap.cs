using UnityEngine;

// Lightweight bootstrapper to ensure a RuntimeUIManager exists and a runtime canvas scaffold is available.
// This module is intentionally small to keep HUD surface minimal for now.

// Lightweight bootstrapper for runtime UI canvas and hooks for HUD elements.
// Keeps HUD minimal for now and ready for future extension.
public class RuntimeUIBootstrap : MonoBehaviour
{
    private static bool s_initialized = false;

    void Awake()
    {
        if (s_initialized) return;
        s_initialized = true;

        // If there is already a canvas managed by RuntimeUIManager, do nothing here.
        var existing = FindObjectOfType<RuntimeUIManager>();
        if (existing == null)
        {
            var go = new GameObject("RuntimeUIManager");
            go.AddComponent<RuntimeUIManager>();
        }
    }
}
