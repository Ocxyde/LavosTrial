using UnityEngine;

// Bootstraps Health, Mana, and Stamina UI Bridges at startup.
// This ensures the runtime UI bars are present without manual scene edits.
public class RuntimeUIBridgesBootstrap : MonoBehaviour
{
    void Awake()
    {
        Debug.Log("[Startup] RuntimeUIBridgesBootstrap Awake start");
        EnsureBridgeExists<RuntimeUIHealthBridge>("Health");
        EnsureBridgeExists<RuntimeUIManaBridge>("Mana");
        EnsureBridgeExists<RuntimeUIStaminaBridge>("Stamina");
    }

    private void EnsureBridgeExists<T>(string id) where T : MonoBehaviour
    {
        var existing = UnityEngine.Object.FindFirstObjectByType<T>();
        if (existing != null) {
            Debug.Log($"[RuntimeUIBridgesBootstrap] {id} bridge already present: {typeof(T).Name}");
            return;
        }
        var go = new GameObject(typeof(T).Name);
        go.AddComponent<T>();
        Debug.Log($"[RuntimeUIBridgesBootstrap] Created {id} bridge: {typeof(T).Name}");
        Debug.Log($"[Startup] UI bridge {id} instantiated at startup");
        Debug.Log($"[Startup] placement intent: Health left, Mana right, Stamina bottom (for {id})");
    }
}
