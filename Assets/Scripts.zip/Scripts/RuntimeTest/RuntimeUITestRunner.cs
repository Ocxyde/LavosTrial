using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System;

public class RuntimeUITestRunner : MonoBehaviour
{
    // Configurable in the inspector
    public string statusBarId = "TestHealth";
    public Vector2 statusBarPosition = new Vector2(50f, -80f); // anchored pos
    public Vector2 statusBarSize = new Vector2(400f, 20f);
    public Color statusBarColor = Color.red;

    private RuntimeUIManager _uiManager;
    private StatusBar _statusBar;

    void Start()
    {
        // Ensure a canonical RuntimeUIManager exists
        _uiManager = RuntimeUIManager.Instance;
        if (_uiManager == null)
        {
            // Try to locate or create a canonical manager in the project
            var go = new GameObject("RuntimeUIManager_Canonical");
            _uiManager = go.AddComponent<RuntimeUIManager>();
        }

        if (_uiManager != null)
        {
            _statusBar = _uiManager.CreateStatusBar(statusBarId, statusBarPosition, statusBarSize, statusBarColor);
        }

        // Start a simple animation to verify updates
        StartCoroutine(AnimateStatusBar());
    }

    IEnumerator AnimateStatusBar()
    {
        if (_uiManager == null || _statusBar == null) yield break;

        float t = 0f;
        while (true)
        {
            t += Time.deltaTime;
            float value = 0.2f + 0.8f * (0.5f + 0.5f * Mathf.Sin(t * 1.5f));
            _uiManager.UpdateStatus(statusBarId, Mathf.Clamp01(value));
            yield return null;
        }
    }
}
