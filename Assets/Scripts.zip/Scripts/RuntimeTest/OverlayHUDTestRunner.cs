using UnityEngine;
using System.Collections;

// Simple runtime test harness to verify HUD overlay behavior in Play mode.
public class OverlayHUDTestRunner : MonoBehaviour
{
    private OverlayHUDManager _overlay;
    void Awake()
    {
        // Ensure the overlay manager exists in the scene if not, create a GameObject and attach
        var go = new GameObject("OverlayHUDManager_Auto");
        _overlay = go.AddComponent<OverlayHUDManager>();
    }

    void Start()
    {
        // Initialize overlay if UI is available; otherwise log will appear from the manager
        StartCoroutine(BlinkBarsRoutine());
    }

    IEnumerator BlinkBarsRoutine()
    {
        float t = 0f;
        while (true)
        {
            t += Time.deltaTime;
            float health = (Mathf.Sin(t) * 0.5f + 0.5f);
            float mana = (Mathf.Cos(t) * 0.5f + 0.5f);
            float stamina = (Mathf.Sin(t * 0.5f) * 0.5f + 0.5f);
            _overlay?.UpdateHealth(health);
            _overlay?.UpdateMana(mana);
            _overlay?.UpdateStamina(stamina);
            yield return null;
        }
    }
}
