// Unity-friendly runtime HUD overlay with optional UnityEngine.UI dependency.
// If UI package is present, renders Health, Mana, and Stamina bars on a Screen Space Overlay canvas.
// If UI is absent, compiles but renders nothing.
using System;
using UnityEngine;

public class OverlayHUDManager : MonoBehaviour
{
    public static OverlayHUDManager Instance { get; private set; }

    // Runtime UI guard: only compile-time include UI types when available
    private bool _uiAvailable;
    private HUDBar _healthBar;
    private HUDBar _manaBar;
    private HUDBar _staminaBar;

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);
        TryInitUI();
    }

    void TryInitUI()
    {
        // Centralize UI availability: TryCreateUIRoot returns a bool
        _uiAvailable = TryCreateUIRoot();
        if (!_uiAvailable)
        {
            Debug.LogWarning("OverlayHUDManager: Unity UI package not found; HUD overlay will be disabled at runtime.");
        }
        if (_uiAvailable) BuildBars();
    }

    // Expose created UI root for external use
    public GameObject OverlayUIRoot { get; private set; }

    bool TryCreateUIRoot()
    {
#if UNITY_2019_1_OR_NEWER
        // Runtime guard: UI package may be absent even when building for newer Unity.
        // Use reflection to detect UI types and avoid compile-time hard dependency.
        var uiType = Type.GetType("UnityEngine.UI.Canvas, UnityEngine.UI");
        if (uiType == null)
        {
            // UI types not available at runtime
            OverlayUIRoot = null;
            return false;
        }

        // Attempt to create a runtime UI Canvas only if UnityEngine.UI is present
        GameObject canvasGO = null;
        try
        {
            // If an OverlayHUDCanvas already exists, reuse it (and ensure it has required components)
            var existing = transform.Find("OverlayHUDCanvas");
            if (existing != null)
            {
                var existingCanvas = existing.GetComponent<UnityEngine.UI.Canvas>();
                var hasRequired = existingCanvas != null && existing.GetComponent<UnityEngine.UI.CanvasScaler>() != null && existing.GetComponent<UnityEngine.UI.GraphicRaycaster>() != null;
                if (hasRequired)
                {
                    OverlayUIRoot = existing.gameObject;
                    _uiAvailable = true;
                    return true;
                }
            }
            // If existing is not suitable or missing components, recreate a fresh UI root
            canvasGO = new GameObject("OverlayHUDCanvas");
            var canvas = canvasGO.AddComponent<UnityEngine.UI.Canvas>();
            canvas.renderMode = UnityEngine.UI.RenderMode.ScreenSpaceOverlay;
            canvasGO.AddComponent<UnityEngine.UI.CanvasScaler>();
            canvasGO.AddComponent<UnityEngine.UI.GraphicRaycaster>();
            // Attach to parent and expose root
            canvasGO.transform.SetParent(transform, false);
            OverlayUIRoot = canvasGO;
            _uiAvailable = true;
            return true;
        }
        catch (System.Exception ex)
        {
            // Cleanup any partially created object to avoid leaks
            if (canvasGO != null)
            {
                UnityEngine.Object.Destroy(canvasGO);
            }
            OverlayUIRoot = null;
            _uiAvailable = false;
            UnityEngine.Debug.LogWarning("UI root creation failed: " + ex.ToString());
            return false;
        }
#else
        return false;
#endif
    }

        void BuildBars()
    {
        if (_healthBar != null) return;
        // Create a simple horizontal stack of three bars using HUDBar inside a container
        var root = new GameObject("HUDRoot");
        root.transform.SetParent(this.transform, false);
        var rt = root.AddComponent<RectTransform>();
        rt.anchorMin = new Vector2(0f, 1f); rt.anchorMax = new Vector2(0f, 1f);
        rt.pivot = new Vector2(0f, 1f); rt.anchoredPosition = new Vector2(12f, -12f); rt.sizeDelta = new Vector2(420f, 60f);
        var hb1 = HUDBar.Create(root.transform, new UnityEngine.Color(1f,0f,0f), "Health"); _healthBar = hb1;
        var hb2 = HUDBar.Create(root.transform, new UnityEngine.Color(0f,1f,0f), "Mana"); _manaBar = hb2;
        var hb3 = HUDBar.Create(root.transform, new UnityEngine.Color(0f,0f,1f), "Stamina"); _staminaBar = hb3;
    }

    public void UpdateHealth(float v) { if (_healthBar != null) _healthBar.Set(v); }
    public void UpdateMana(float v) { if (_manaBar != null) _manaBar.Set(v); }
    public void UpdateStamina(float v) { if (_staminaBar != null) _staminaBar.Set(v); }
    void OnDestroy()
    {
        if (OverlayUIRoot != null)
        {
            UnityEngine.Object.Destroy(OverlayUIRoot);
            OverlayUIRoot = null;
        }
        if (Instance == this) Instance = null;
    }
}

// Minimal bar with a fill image; guarded for UI package absence
public class HUDBar : MonoBehaviour
{
    private UnityEngine.UI.Image _fill;
    public static HUDBar Create(Transform parent, UnityEngine.Color color, string label)
    {
#if UNITY_2019_1_OR_NEWER
        var go = new GameObject(label + "_Bar");
        go.transform.SetParent(parent, false);
        var rt = go.AddComponent<RectTransform>();
        rt.sizeDelta = new Vector2(120f, 20f);
        var bar = go.AddComponent<HUDBar>();
        var bg = new GameObject("Background"); bg.transform.SetParent(go.transform, false);
        var brt = bg.AddComponent<RectTransform>(); brt.anchorMin = Vector2.zero; brt.anchorMax = Vector2.one; brt.offsetMin = Vector2.zero; brt.offsetMax = Vector2.zero;
        var bgImg = bg.AddComponent<UnityEngine.UI.Image>(); bgImg.color = new UnityEngine.Color(0,0,0,0.25f);
        var fillGo = new GameObject("Fill"); fillGo.transform.SetParent(go.transform, false);
        var frt = fillGo.AddComponent<RectTransform>(); frt.anchorMin = Vector2.zero; frt.anchorMax = Vector2.one; frt.offsetMin = Vector2.zero; frt.offsetMax = Vector2.zero;
        var fill = fillGo.AddComponent<UnityEngine.UI.Image>(); fill.type = UnityEngine.UI.Image.Type.Filled; fill.fillMethod = UnityEngine.UI.Image.FillMethod.Horizontal; fill.color = color;
        bar._fill = fill;
        return bar;
#else
        return null;
#endif
    }
    public void Set(float value)
    {
        if (_fill != null) _fill.fillAmount = Mathf.Clamp01(value);
    }
}
