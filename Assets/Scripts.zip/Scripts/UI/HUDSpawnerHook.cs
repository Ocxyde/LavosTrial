using UnityEngine;

// HUD Spawner Hook: wires HUD on player spawn if available
public class HUDSpawnerHook : MonoBehaviour
{
    void Start()
    {
        TrySpawnHUD();
    }

    void OnEnable()
    {
        // If there is a central event for player spawn, subscribe here
        // Example: PlayerSpawnEvent.OnSpawn += OnPlayerSpawn;
    }

    void OnDisable()
    {
        // If subscribed to events, unsubscribe here
        // Example: PlayerSpawnEvent.OnSpawn -= OnPlayerSpawn;
    }

    private void TrySpawnHUD()
    {
        if (HUDGenerator.Instance != null)
        {
            HUDGenerator.Instance.InitHUD();
            Debug.Log("[HUDSpawnerHook] HUD InitHUD called after Start");
        }
        else
        {
            Debug.Log("[HUDSpawnerHook] HUDGenerator not ready yet, InitHUD deferred");
        }
    }
}
