using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UI;

// Lightweight status bar component for future HUD; keeps compatibility with runtime UI scaffold.
public class MinimalStatusBar : MonoBehaviour
{
    [SerializeField] private Image fillImage;
    [SerializeField] private Text label;

    public void SetValue(float v)
    {
        if (fillImage != null) fillImage.fillAmount = Mathf.Clamp01(v);
        if (label != null) label.text = Mathf.RoundToInt(v * 100).ToString() + "%";
    }

    public Image FillImage => fillImage;
}
