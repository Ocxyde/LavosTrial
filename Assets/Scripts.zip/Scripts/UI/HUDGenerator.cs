using UnityEngine;
using UnityEngine.UI;

// Central HUD generator: single source of truth for on-screen HUD (health, mana, stamina, toasts, inventory popups)
public class HUDGenerator : MonoBehaviour
{
    public static HUDGenerator Instance { get; private set; }

    private Canvas _overlayCanvas;
    private RectTransform _healthBar;
    private RectTransform _manaBar;
    private RectTransform _staminaBar;
    private Transform _root; // overlay root for future panels

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(this.gameObject);
        EnsureOverlayCanvas();
        BuildBars();
        Debug.Log("[HUDGenerator] HUD overlay initialized");
    }

    private void EnsureOverlayCanvas()
    {
        _overlayCanvas = UnityEngine.Object.FindFirstObjectByType<Canvas>();
        if (_overlayCanvas == null)
        {
            var go = new GameObject("OverlayHUDCanvas");
            _overlayCanvas = go.AddComponent<Canvas>();
            _overlayCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
            go.AddComponent<CanvasScaler>();
            go.AddComponent<GraphicRaycaster>();
            Debug.Log("[HUDGenerator] Created Overlay HUD Canvas (ScreenSpaceOverlay)");
        }
        _root = _overlayCanvas.transform;
    }

    private void BuildBars()
    {
        if (_overlayCanvas == null) return;
        // Health (top-left)
        _healthBar = CreateBar("HealthBar", new Vector2(12f, -12f), new Vector2(220f, 20f), Color.green, _overlayCanvas.transform);
        // Mana (top-right)
        _manaBar = CreateBar("ManaBar", new Vector2(-12f, -12f), new Vector2(200f, 20f), Color.cyan, _overlayCanvas.transform, rightAnchor:true);
        // Stamina (bottom-center)
        _staminaBar = CreateBar("StaminaBar", new Vector2(0f, 40f), new Vector2(200f, 20f), Color.blue, _overlayCanvas.transform, bottomAnchor:true);
    }

    private RectTransform CreateBar(string name, Vector2 anchoredPosition, Vector2 size, Color color, Transform parent, bool rightAnchor=false, bool bottomAnchor=false)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent, false);
        var rt = go.AddComponent<RectTransform>();
        if (rightAnchor)
        {
            rt.anchorMin = new Vector2(1f, 1f);
            rt.anchorMax = new Vector2(1f, 1f);
            rt.pivot = new Vector2(1f, 1f);
        }
        else if (bottomAnchor)
        {
            rt.anchorMin = new Vector2(0.5f, 0f);
            rt.anchorMax = new Vector2(0.5f, 0f);
            rt.pivot = new Vector2(0.5f, 0f);
        }
        else
        {
            rt.anchorMin = new Vector2(0f, 1f);
            rt.anchorMax = new Vector2(0f, 1f);
            rt.pivot = new Vector2(0f, 1f);
        }
        rt.anchoredPosition = anchoredPosition;
        rt.sizeDelta = size;
        var img = go.AddComponent<Image>();
        img.color = color;
        return rt;
    }

    public void InitHUD()
    {
        // Show HUD if hidden by default; could activate panels here later
        if (_overlayCanvas != null) _overlayCanvas.enabled = true;
        Debug.Log("[HUDGenerator] InitHUD invoked");
        // Ensure the Health/Mana/Stamina bars exist and are in the expected positions
        if (_healthBar != null) Debug.Log("[HUDGenerator] Health bar present at " + _healthBar.anchoredPosition);
        if (_manaBar != null) Debug.Log("[HUDGenerator] Mana bar present at " + _manaBar.anchoredPosition);
        if (_staminaBar != null) Debug.Log("[HUDGenerator] Stamina bar present at " + _staminaBar.anchoredPosition);
    }

    // Basic API to show a toast on overlay (future extension)
    public void ShowToast(string message, float duration = 2f)
    {
        Debug.Log("[HUDGenerator] ShowToast: " + message);
        // Placeholder: you would instantiate a toast panel under _root with animation
    }
}
