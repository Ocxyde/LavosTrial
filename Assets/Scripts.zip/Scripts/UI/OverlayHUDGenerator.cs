using UnityEngine;
using UnityEngine.UI;

// Overlay HUD generator: creates a Screen Space Overlay canvas and basic HUD bars.
public class OverlayHUDGenerator : MonoBehaviour
{
    public static OverlayHUDGenerator Instance { get; private set; }

    private Canvas _overlayCanvas;
    private RectTransform _healthBar;
    private RectTransform _manaBar;
    private RectTransform _staminaBar;

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(this.gameObject);
        CreateOverlayCanvasIfNeeded();
        BuildHUDBars();
        Debug.Log("[OverlayHUDGenerator] Overlay HUD initialized");
    }

    void CreateOverlayCanvasIfNeeded()
    {
        // Try to reuse existing RuntimeUI canvas if present
        _overlayCanvas = UnityEngine.Object.FindFirstObjectByType<Canvas>();
        if (_overlayCanvas == null || _overlayCanvas.renderMode != RenderMode.ScreenSpaceOverlay)
        {
            GameObject go = new GameObject("OverlayHUDCanvas");
            _overlayCanvas = go.AddComponent<Canvas>();
            _overlayCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
            go.AddComponent<CanvasScaler>();
            go.AddComponent<GraphicRaycaster>();
            Debug.Log("[OverlayHUDGenerator] Created Overlay Canvas (ScreenSpaceOverlay)");
        }
    }

    void BuildHUDBars()
    {
        if (_overlayCanvas == null) return;
        // Health bar (top-left)
        var healthGO = new GameObject("HealthBar");
        healthGO.transform.SetParent(_overlayCanvas.transform, false);
        var healthRT = healthGO.AddComponent<RectTransform>();
        healthRT.anchorMin = new Vector2(0f, 1f);
        healthRT.anchorMax = new Vector2(0f, 1f);
        healthRT.pivot = new Vector2(0f, 1f);
        healthRT.anchoredPosition = new Vector2(12f, -12f);
        healthRT.sizeDelta = new Vector2(220f, 20f);
        var healthImg = healthGO.AddComponent<Image>();
        healthImg.color = new Color(0f, 0.5f, 0f, 0.8f);
        _healthBar = healthRT;

        // Mana bar (top-right)
        var manaGO = new GameObject("ManaBar");
        manaGO.transform.SetParent(_overlayCanvas.transform, false);
        var manaRT = manaGO.AddComponent<RectTransform>();
        manaRT.anchorMin = new Vector2(1f, 1f);
        manaRT.anchorMax = new Vector2(1f, 1f);
        manaRT.pivot = new Vector2(1f, 1f);
        manaRT.anchoredPosition = new Vector2(-12f, -12f);
        manaRT.sizeDelta = new Vector2(200f, 20f);
        var manaImg = manaGO.AddComponent<Image>();
        manaImg.color = new Color(0f, 0.5f, 0.5f, 0.9f);
        _manaBar = manaRT;

        // Stamina bar (bottom-center)
        var staminaGO = new GameObject("StaminaBar");
        staminaGO.transform.SetParent(_overlayCanvas.transform, false);
        var staminaRT = staminaGO.AddComponent<RectTransform>();
        staminaRT.anchorMin = new Vector2(0.5f, 0f);
        staminaRT.anchorMax = new Vector2(0.5f, 0f);
        staminaRT.pivot = new Vector2(0.5f, 0f);
        staminaRT.anchoredPosition = new Vector2(0f, 40f);
        staminaRT.sizeDelta = new Vector2(200f, 20f);
        var staminaImg = staminaGO.AddComponent<Image>();
        staminaImg.color = new Color(0f, 0f, 0.8f, 0.85f);
        _staminaBar = staminaRT;
    }

    public void InitOnSpawn()
    {
        // Reveal overlay elements on player spawn if needed (already created in Awake)
        if (_overlayCanvas != null) _overlayCanvas.enabled = true;
        Debug.Log("[OverlayHUDGenerator] InitOnSpawn invoked – overlay HUD shown");
    }
}
