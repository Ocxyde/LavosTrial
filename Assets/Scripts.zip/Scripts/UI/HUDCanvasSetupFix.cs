using UnityEngine;
using UnityEngine.UI;

// Force-init HUD canvas and bars for reliable Play-mode visuals.
// This patch creates a HUDCanvas, OverlayRoot, and Health/Mana/Stamina bars on Start if they are missing.
public class HUDCanvasSetupFix : MonoBehaviour
{
    void Awake()
    {
        // Ensure HUD canvas exists and is ScreenSpaceOverlay
        var canvas = UnityEngine.Object.FindFirstObjectByType<Canvas>();
        if (canvas == null)
        {
            var go = new GameObject("HUDCanvas");
            canvas = go.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            go.AddComponent<CanvasScaler>();
            go.AddComponent<GraphicRaycaster>();
            Debug.Log("[HUDCanvasSetupFix] HUDCanvas created (ScreenSpaceOverlay)");
        }
        // OverlayRoot
        var root = new GameObject("OverlayRoot");
        root.transform.SetParent(canvas.transform, false);
        var rt = root.AddComponent<RectTransform>();
        rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one; rt.offsetMin = Vector2.zero; rt.offsetMax = Vector2.zero;
        Debug.Log("[HUDCanvasSetupFix] OverlayRoot created");

        // Bars (Health, Mana, Stamina)
        CreateBar("HealthBar", new Vector2(12f, -12f), new Vector2(220f, 20f), Color.green, root.transform, 0f);
        CreateBar("ManaBar", new Vector2(-12f, -12f), new Vector2(200f, 20f), Color.cyan, root.transform, 1f);
        CreateBar("StaminaBar", new Vector2(0f, 40f), new Vector2(200f, 20f), Color.blue, root.transform, 0f, true);

        // Init HUD through the existing HUDGenerator path if present
        var gen = HUDGenerator.Instance;
        gen?.InitHUD();
        Debug.Log("[HUDCanvasSetupFix] Forced InitHUD called if HUDGenerator present");
    }

    private RectTransform CreateBar(string name, Vector2 pos, Vector2 size, Color color, Transform parent, float leftOrRight = 0f, bool bottom = false)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent, false);
        var rt = go.AddComponent<RectTransform>();
        rt.sizeDelta = size;
        // Default to left anchor; adapt if right/bottom on call
        rt.anchorMin = new Vector2(0f, 1f);
        rt.anchorMax = new Vector2(0f, 1f);
        rt.pivot = new Vector2(0f, 1f);
        rt.anchoredPosition = pos;
        var img = go.AddComponent<Image>();
        img.color = color;
        return rt;
    }
}
