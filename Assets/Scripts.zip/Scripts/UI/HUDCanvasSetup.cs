using UnityEngine;
using UnityEngine.UI;

// Global HUD Canvas: a single reusable overlay canvas for Health, Mana, Stamina, toasts, inventory popups
public class HUDCanvasSetup : MonoBehaviour
{
    public static HUDCanvasSetup Instance { get; private set; }

    public Canvas HUDCanvas { get; private set; }
    public RectTransform OverlayRoot { get; private set; }
    public RectTransform HealthBar { get; private set; }
    public RectTransform ManaBar { get; private set; }
    public RectTransform StaminaBar { get; private set; }

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(this.gameObject);
        CreateOrFindHUDCanvas();
        BuildDefaultBars();
        Debug.Log("[HUDCanvasSetup] HUD canvas and bars initialized");
    }

    private void CreateOrFindHUDCanvas()
    {
        HUDCanvas = UnityEngine.Object.FindFirstObjectByType<Canvas>();
        if (HUDCanvas == null || HUDCanvas.renderMode != RenderMode.ScreenSpaceOverlay)
        {
            var go = new GameObject("HUDCanvas");
            HUDCanvas = go.AddComponent<Canvas>();
            HUDCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
            go.AddComponent<CanvasScaler>();
            go.AddComponent<GraphicRaycaster>();
            Debug.Log("[HUDCanvasSetup] Created HUDCanvas (ScreenSpaceOverlay)");
        }
        OverlayRoot = new GameObject("OverlayRoot").transform as RectTransform;
        OverlayRoot.SetParent(HUDCanvas.transform, false);
        OverlayRoot.localScale = Vector3.one;
        // Ensure root has a RectTransform (as a container for panels)
        if (OverlayRoot.GetComponent<RectTransform>() == null) OverlayRoot.gameObject.AddComponent<RectTransform>();
        OverlayRoot.anchoredPosition = Vector2.zero;
        OverlayRoot.sizeDelta = Vector2.zero;
    }

    private void BuildDefaultBars()
    {
        if (HUDCanvas == null || OverlayRoot == null) return;
        HealthBar = CreateBar("HealthBar", new Vector2(12f, -12f), new Vector2(220f, 20f), Color.green, OverlayRoot, left:true);
        ManaBar = CreateBar("ManaBar", new Vector2(-12f, -12f), new Vector2(200f, 20f), Color.cyan, OverlayRoot, right:true);
        StaminaBar = CreateBar("StaminaBar", new Vector2(0f, 40f), new Vector2(200f, 20f), Color.blue, OverlayRoot, bottom:true);
    }

    private RectTransform CreateBar(string name, Vector2 anchoredPosition, Vector2 size, Color color, Transform parent, bool left=false, bool right=false, bool bottom=false)
    {
        var barGO = new GameObject(name);
        barGO.transform.SetParent(parent, false);
        var rt = barGO.AddComponent<RectTransform>();
        if (left)
        {
            rt.anchorMin = new Vector2(0f, 1f); rt.anchorMax = new Vector2(0f, 1f); rt.pivot = new Vector2(0f, 1f);
            rt.anchoredPosition = anchoredPosition;
        }
        else if (right)
        {
            rt.anchorMin = new Vector2(1f, 1f); rt.anchorMax = new Vector2(1f, 1f); rt.pivot = new Vector2(1f, 1f);
            rt.anchoredPosition = anchoredPosition;
        }
        else if (bottom)
        {
            rt.anchorMin = new Vector2(0.5f, 0f); rt.anchorMax = new Vector2(0.5f, 0f); rt.pivot = new Vector2(0.5f, 0f);
            rt.anchoredPosition = anchoredPosition;
        }
        else
        {
            rt.anchorMin = new Vector2(0f, 1f); rt.anchorMax = new Vector2(0f, 1f); rt.pivot = new Vector2(0f, 1f);
            rt.anchoredPosition = anchoredPosition;
        }
        rt.sizeDelta = size;
        var img = barGO.AddComponent<Image>();
        img.color = color;
        return rt;
    }

    public RectTransform GetHealthBar() => HealthBar;
    public RectTransform GetManaBar() => ManaBar;
    public RectTransform GetStaminaBar() => StaminaBar;
}
