using UnityEngine.UI;
using UnityEngine;

// Lightweight status bar wrapper for health/stamina
public class StatusBar : MonoBehaviour
{
    public UnityEngine.UI.Image fillImage;
    [SerializeField] private bool invert = false;

    public void SetValue(float t)
    {
        if (fillImage != null)
        {
            fillImage.fillAmount = Mathf.Clamp01(t);
            if (invert) fillImage.fillAmount = 1f - fillImage.fillAmount;
        }
    }
}
