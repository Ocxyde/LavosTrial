using UnityEngine;

// Global, persistent HUD bootstrap: ensures a single overlay HUD canvas and bars exist across scenes
public class HUDGlobalBootstrap : MonoBehaviour
{
    private static bool _initialized = false;
    void Awake()
    {
        if (_initialized) return;
        _initialized = true;

        // Ensure a HUDCanvas exists
        HUDCanvasSetup canvasSetup = FindObjectOfType<HUDCanvasSetup>();
        if (canvasSetup == null)
        {
            var go = new GameObject("HUDCanvasSetup");
            canvasSetup = go.AddComponent<HUDCanvasSetup>();
        }
        // Ensure HUDGenerator is present and ready
        var hud = FindObjectOfType<HUDGenerator>();
        if (hud == null)
        {
            var go2 = new GameObject("HUDGenerator");
            go2.AddComponent<HUDGenerator>();
        }
        // Ensure bridges bootstrap
        var bridge = FindObjectOfType<RuntimeUIBridgesBootstrap>();
        if (bridge == null)
        {
            var go3 = new GameObject("RuntimeUIBridgesBootstrap");
            go3.AddComponent<RuntimeUIBridgesBootstrap>();
        }
        // Init HUD after a slight delay to allow spawn hooks to fire
        StartCoroutine(InitHUDAfterSpawn());
    }

    private System.Collections.IEnumerator InitHUDAfterSpawn()
    {
        // wait for a frame to let other systems initialize
        yield return null;
        HUDGenerator hud = FindObjectOfType<HUDGenerator>();
        hud?.InitHUD();
        Debug.Log("[HUDGlobalBootstrap] HUD InitHUD invoked on startup");
    }
}
