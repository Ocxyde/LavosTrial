using UnityEngine;
using UnityEngine.UI;
using UnityEngine.InputSystem;
using TMPro;

/// <summary>
/// UIMANAGER — HUD complet avec le nouveau Input System (Unity 6)
///
/// SETUP dans Unity :
///  1. Crée un Canvas dans ta scène
///  2. Attache ce script sur le Canvas
///  3. Assigne chaque élément UI dans l'Inspector
///
/// Structure Canvas recommandée :
///  Canvas
///  ├── HUD_Panel
///  │    ├── HealthBar    (Slider)
///  │    ├── StaminaBar   (Slider)
///  │    ├── Score_Text   (TextMeshProUGUI)
///  │    └── Crosshair    (Image)
///  ├── Pause_Panel       (désactivé par défaut)
///  │    ├── Resume_Button
///  │    └── Quit_Button
///  └── GameOver_Panel    (désactivé par défaut)
///       ├── FinalScore_Text
///       └── Restart_Button
/// </summary>
public class UIManager : MonoBehaviour
{
    // ─── Singleton ────────────────────────────────────────────────────────────
    public static UIManager Instance { get; private set; }

    // ─── HUD ──────────────────────────────────────────────────────────────────
    [Header("HUD — Barre de vie")]
    [SerializeField] private Slider          healthBar;
    [SerializeField] private TextMeshProUGUI healthText;
    [SerializeField] private Image           healthFill;
    [SerializeField] private Color           healthColorFull = Color.green;
    [SerializeField] private Color           healthColorLow  = Color.red;

    [Header("HUD — Barre de stamina")]
    [SerializeField] private Slider          staminaBar;
    [SerializeField] private TextMeshProUGUI staminaText;

    [Header("HUD — Barre de mana")]
    [SerializeField] private Slider          manaBar;
    [SerializeField] private TextMeshProUGUI manaText;
    [SerializeField] private Image           manaFill;
    [SerializeField] private Color           manaColorFull = Color.blue;
    [SerializeField] private Color           manaColorLow  = Color.cyan;

    [Header("HUD — Score")]
    [SerializeField] private TextMeshProUGUI scoreText;

    [Header("HUD — Viseur")]
    [SerializeField] private GameObject crosshair;

    // ─── Pause ────────────────────────────────────────────────────────────────
    [Header("Menu Pause")]
    [SerializeField] private GameObject pausePanel;
    [SerializeField] private Button     resumeButton;
    [SerializeField] private Button     quitButton;

    // ─── Game Over ────────────────────────────────────────────────────────────
    [Header("Game Over")]
    [SerializeField] private GameObject      gameOverPanel;
    [SerializeField] private TextMeshProUGUI finalScoreText;
    [SerializeField] private Button          restartButton;

    // ─── Victory ─────────────────────────────────────────────────────────────
    [Header("Victory")]
    [SerializeField] private GameObject      victoryPanel;
    [SerializeField] private TextMeshProUGUI victoryText;
    [SerializeField] private Button          victoryRestartButton;

    // ─── HUD Panel ────────────────────────────────────────────────────────────
    [Header("HUD Panel")]
    [SerializeField] private GameObject hudPanel;

    // ─── Popup ────────────────────────────────────────────────────────────────
    [Header("Message temporaire")]
    [SerializeField] private TextMeshProUGUI popupText;
    [SerializeField] private float           popupDuration = 2f;

    private Coroutine _popupCoroutine;

    // ─── Input System ─────────────────────────────────────────────────────────
    private Keyboard _kb;

    // ─────────────────────────────────────────────────────────────────────────
    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        _kb = Keyboard.current;
    }

    void Start()
    {
        // Abonnements aux événements
        PlayerHealth.OnHealthChanged        += UpdateHealthUI;
        PlayerController.OnStaminaChanged   += UpdateStaminaUI;
        PlayerStats.Instance.OnManaChanged += UpdateManaUI;
        GameManager.OnScoreChanged          += UpdateScoreUI;
        GameManager.OnGameStateChanged      += HandleGameStateChanged;

        // Boutons
        resumeButton?.onClick.AddListener(OnResumeClicked);
        quitButton?.onClick.AddListener(OnQuitClicked);
        restartButton?.onClick.AddListener(OnRestartClicked);
        victoryRestartButton?.onClick.AddListener(OnRestartClicked);

        // État initial
        if (pausePanel) pausePanel.SetActive(false);
        if (gameOverPanel) gameOverPanel.SetActive(false);
        if (victoryPanel) victoryPanel.SetActive(false);
        if (hudPanel) hudPanel.SetActive(true);
    }

    void OnDestroy()
    {
        PlayerHealth.OnHealthChanged        -= UpdateHealthUI;
        PlayerController.OnStaminaChanged   -= UpdateStaminaUI;
        if (PlayerStats.Instance != null)
            PlayerStats.Instance.OnManaChanged -= UpdateManaUI;
        GameManager.OnScoreChanged          -= UpdateScoreUI;
        GameManager.OnGameStateChanged      -= HandleGameStateChanged;
    }

    void Update()
    {
        if (_kb == null) return;

        // Échap = Pause (nouveau Input System)
        if (_kb.escapeKey.wasPressedThisFrame)
            GameManager.Instance?.TogglePause();
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  VIE
    // ─────────────────────────────────────────────────────────────────────────
    private void UpdateHealthUI(float current, float max)
    {
        if (healthBar != null)
        {
            healthBar.maxValue = max;
            healthBar.value    = current;
        }

        if (healthText != null)
            healthText.text = $"{Mathf.CeilToInt(current)} / {Mathf.CeilToInt(max)}";

        if (healthFill != null)
            healthFill.color = Color.Lerp(healthColorLow, healthColorFull, current / max);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  STAMINA
    // ─────────────────────────────────────────────────────────────────────────
    private void UpdateStaminaUI(float current, float max)
    {
        if (staminaBar != null)
        {
            staminaBar.maxValue = max;
            staminaBar.value    = current;
        }

        if (staminaText != null)
            staminaText.text = $"{Mathf.CeilToInt(current)}";
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  MANA
    // ─────────────────────────────────────────────────────────────────────────
    private void UpdateManaUI(float current, float max)
    {
        if (manaBar != null)
        {
            manaBar.maxValue = max;
            manaBar.value    = current;
        }

        if (manaText != null)
            manaText.text = $"{Mathf.CeilToInt(current)} / {Mathf.CeilToInt(max)}";

        if (manaFill != null)
            manaFill.color = Color.Lerp(manaColorLow, manaColorFull, max > 0 ? current / max : 0);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  SCORE
    // ─────────────────────────────────────────────────────────────────────────
    private void UpdateScoreUI(int score)
    {
        if (scoreText != null)
            scoreText.text = $"Score : {score}";
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  ÉTATS DU JEU
    // ─────────────────────────────────────────────────────────────────────────
    private void HandleGameStateChanged(GameManager.GameState state)
    {
        switch (state)
        {
            case GameManager.GameState.Playing:
                pausePanel?.SetActive(false);
                gameOverPanel?.SetActive(false);
                victoryPanel?.SetActive(false);
                hudPanel?.SetActive(true);
                crosshair?.SetActive(true);
                Cursor.lockState = CursorLockMode.Locked;
                Cursor.visible   = false;
                break;

            case GameManager.GameState.Paused:
                pausePanel?.SetActive(true);
                hudPanel?.SetActive(false);
                crosshair?.SetActive(false);
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible   = true;
                break;

            case GameManager.GameState.GameOver:
                gameOverPanel?.SetActive(true);
                hudPanel?.SetActive(false);
                crosshair?.SetActive(false);
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible   = true;
                if (finalScoreText != null && GameManager.Instance != null)
                    finalScoreText.text = $"Score final : {GameManager.Instance.Score}";
                break;

            case GameManager.GameState.Victory:
                victoryPanel?.SetActive(true);
                hudPanel?.SetActive(false);
                crosshair?.SetActive(false);
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible   = true;
                if (victoryText != null && GameManager.Instance != null)
                    victoryText.text = $"Victoire ! Score : {GameManager.Instance.Score}";
                break;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  BOUTONS
    // ─────────────────────────────────────────────────────────────────────────
    private void OnResumeClicked()
    {
        GameManager.Instance?.TogglePause();
    }

    private void OnQuitClicked()
    {
        Debug.Log("[UIManager] Quitter");
        Application.Quit();
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#endif
    }

    private void OnRestartClicked()
    {
        GameManager.Instance?.RestartGame();
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  POPUP
    // ─────────────────────────────────────────────────────────────────────────
    public void ShowPopup(string message)
    {
        if (popupText == null) return;
        if (_popupCoroutine != null) StopCoroutine(_popupCoroutine);
        _popupCoroutine = StartCoroutine(PopupRoutine(message));
    }

    private System.Collections.IEnumerator PopupRoutine(string message)
    {
        popupText.text    = message;
        popupText.enabled = true;
        yield return new WaitForSeconds(popupDuration);
        popupText.enabled = false;
    }
}
