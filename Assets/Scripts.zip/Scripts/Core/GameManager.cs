using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// GAMEMANAGER — Cerveau central du jeu (Singleton)
/// Attache ce script à un GameObject vide nommé "GameManager" dans ta scène.
/// Coche "Don't Destroy On Load" pour qu'il persiste entre les scènes.
/// </summary>
public class GameManager : MonoBehaviour
{
    // ─── Singleton ───────────────────────────────────────────────────────────
    public static GameManager Instance { get; private set; }

    // ─── États du jeu ────────────────────────────────────────────────────────
    public enum GameState { Playing, Paused, GameOver, Victory }
    public GameState CurrentState { get; private set; }

    // ─── Score ───────────────────────────────────────────────────────────────
    public int Score { get; private set; }

    // ─── Événements (les autres scripts peuvent s'y abonner) ─────────────────
    public static event System.Action<int>      OnScoreChanged;
    public static event System.Action<GameState> OnGameStateChanged;

    // ─────────────────────────────────────────────────────────────────────────
    void Awake()
    {
        // Implémentation du Singleton
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject); // Persiste entre les scènes
    }

    void Start()
    {
        SetGameState(GameState.Playing);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  MÉTHODES PUBLIQUES
    // ─────────────────────────────────────────────────────────────────────────

    /// <summary>Ajoute des points au score.</summary>
    public void AddScore(int points)
    {
        Score += points;
        OnScoreChanged?.Invoke(Score); // Notifie l'UI
        Debug.Log($"[GameManager] Score : {Score}");
    }

    /// <summary>Change l'état global du jeu.</summary>
    public void SetGameState(GameState newState)
    {
        CurrentState = newState;
        OnGameStateChanged?.Invoke(newState);

        // Gestion du temps selon l'état
        Time.timeScale = (newState == GameState.Paused) ? 0f : 1f;

        Debug.Log($"[GameManager] État du jeu : {newState}");
    }

    /// <summary>Active / désactive la pause.</summary>
    public void TogglePause()
    {
        if (CurrentState == GameState.Playing)
            SetGameState(GameState.Paused);
        else if (CurrentState == GameState.Paused)
            SetGameState(GameState.Playing);
    }

    /// <summary>Déclenche le Game Over.</summary>
    public void TriggerGameOver()
    {
        SetGameState(GameState.GameOver);
    }

    /// <summary>Recharge la scène courante (recommencer).</summary>
    public void RestartGame()
    {
        Score = 0;
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    /// <summary>Charge une scène par son nom.</summary>
    public void LoadScene(string sceneName)
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(sceneName);
    }
}
