using UnityEngine;

/// <summary>
/// COLLECTIBLE — Objet ramassable (pièce, potion, bonus…)
/// 
/// SETUP dans Unity :
///  1. Crée un GameObject (ex: une sphère)
///  2. Attache ce script dessus
///  3. Ajoute un Collider en mode "Is Trigger"
///  4. Choisis le type dans l'Inspector
/// </summary>
public class Collectible : MonoBehaviour
{
    public enum CollectibleType { Score, Health, Stamina }

    [Header("Type et valeur")]
    [SerializeField] private CollectibleType type       = CollectibleType.Score;
    [SerializeField] private float           value      = 50f;   // Points ou HP
    [SerializeField] private string          popupMsg   = "+50 pts";

    [Header("Animation")]
    [SerializeField] private float rotationSpeed = 90f;   // Rotation sur Y (degrés/s)
    [SerializeField] private float bobSpeed      = 1.5f;  // Oscillation verticale
    [SerializeField] private float bobHeight     = 0.3f;

    [Header("Effets")]
    [SerializeField] private GameObject collectVFX;       // Optionnel : particules

    private Vector3 _startPosition;

    // ─────────────────────────────────────────────────────────────────────────
    void Start()
    {
        _startPosition = transform.position;
    }

    void Update()
    {
        // Rotation continue
        transform.Rotate(Vector3.up * rotationSpeed * Time.deltaTime);

        // Oscillation verticale (effet flottant)
        float newY = _startPosition.y + Mathf.Sin(Time.time * bobSpeed) * bobHeight;
        transform.position = new Vector3(transform.position.x, newY, transform.position.z);
    }

    // ─────────────────────────────────────────────────────────────────────────
    void OnTriggerEnter(Collider other)
    {
        // Vérifie que c'est bien le joueur
        if (!other.CompareTag("Player")) return;

        Collect(other.gameObject);
    }

    private void Collect(GameObject player)
    {
        switch (type)
        {
            case CollectibleType.Score:
                GameManager.Instance?.AddScore((int)value);
                break;

            case CollectibleType.Health:
                var health = player.GetComponent<PlayerHealth>();
                health?.Heal(value);
                break;

            case CollectibleType.Stamina:
                // La stamina est gérée dans PlayerController
                // Tu peux ajouter un événement similaire si tu veux
                break;
        }

        // Message popup à l'écran
        if (!string.IsNullOrEmpty(popupMsg))
            UIManager.Instance?.ShowPopup(popupMsg);

        // Effet visuel
        if (collectVFX != null)
            Instantiate(collectVFX, transform.position, Quaternion.identity);

        Debug.Log($"[Collectible] Ramassé : {type} +{value}");

        // Détruit l'objet
        Destroy(gameObject);
    }
}
