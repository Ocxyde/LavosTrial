using UnityEngine;
using System.Collections.Generic;

public enum StatusEffectType
{
    Buff,
    Debuff
}

[System.Serializable]
public class StatusEffect
{
    public string id;
    public string effectName;
    public StatusEffectType type;
    public Sprite icon;
    public float duration;
    public float intensity;
    public int maxStacks = 1;
    public float tickRate;

    public float remainingTime;
    public int currentStacks;
    public float nextTickTime;

    public bool IsExpired => remainingTime <= 0;
}

public class PlayerStats : MonoBehaviour
{
    public static PlayerStats Instance { get; private set; }

    [Header("Health")]
    [SerializeField] private float maxHealth = 100f;
    [SerializeField] private float currentHealth;
    [SerializeField] private float healthRegen = 5f;

    [Header("Mana")]
    [SerializeField] private float maxMana = 50f;
    [SerializeField] private float currentMana;
    [SerializeField] private float manaRegen = 10f;

    [Header("Stamina")]
    [SerializeField] private float maxStamina = 100f;
    [SerializeField] private float currentStamina;
    [SerializeField] private float staminaRegen = 15f;

    [Header("Status Effects")]
    [SerializeField] private List<StatusEffect> activeEffects = new List<StatusEffect>();

    public float MaxHealth => maxHealth;
    public float CurrentHealth => currentHealth;
    public float MaxMana => maxMana;
    public float CurrentMana => currentMana;
    public float MaxStamina => maxStamina;
    public float CurrentStamina => currentStamina;
    public IReadOnlyList<StatusEffect> ActiveEffects => activeEffects;

    public System.Action<float, float> OnHealthChanged;
    public System.Action<float, float> OnManaChanged;
    public System.Action<float, float> OnStaminaChanged;
    public System.Action<StatusEffect> OnEffectAdded;
    public System.Action<StatusEffect> OnEffectRemoved;
    public System.Action OnPlayerDeath;

    private bool _isDead = false;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;

        currentHealth = maxHealth;
        currentMana = maxMana;
        currentStamina = maxStamina;
    }

    private void Update()
    {
        if (_isDead) return;

        RegenerateHealth();
        RegenerateMana();
        RegenerateStamina();
        UpdateStatusEffects();
    }

    private void RegenerateHealth()
    {
        if (currentHealth < maxHealth && healthRegen > 0)
        {
            currentHealth += healthRegen * Time.deltaTime;
            currentHealth = Mathf.Min(currentHealth, maxHealth);
            OnHealthChanged?.Invoke(currentHealth, maxHealth);
        }
    }

    private void RegenerateMana()
    {
        if (currentMana < maxMana && manaRegen > 0)
        {
            currentMana += manaRegen * Time.deltaTime;
            currentMana = Mathf.Min(currentMana, maxMana);
            OnManaChanged?.Invoke(currentMana, maxMana);
        }
    }

    private void RegenerateStamina()
    {
        if (currentStamina < maxStamina && staminaRegen > 0)
        {
            currentStamina += staminaRegen * Time.deltaTime;
            currentStamina = Mathf.Min(currentStamina, maxStamina);
            OnStaminaChanged?.Invoke(currentStamina, maxStamina);
        }
    }

    private void UpdateStatusEffects()
    {
        for (int i = activeEffects.Count - 1; i >= 0; i--)
        {
            StatusEffect effect = activeEffects[i];
            effect.remainingTime -= Time.deltaTime;

            if (effect.tickRate > 0 && Time.time >= effect.nextTickTime)
            {
                ApplyEffectTick(effect);
                effect.nextTickTime = Time.time + effect.tickRate;
            }

            if (effect.IsExpired)
            {
                RemoveEffect(effect);
            }
        }
    }

    private void ApplyEffectTick(StatusEffect effect)
    {
        switch (effect.id)
        {
            case "poison":
                TakeDamage(effect.intensity * effect.currentStacks);
                break;
            case "regeneration":
                Heal(effect.intensity * effect.currentStacks);
                break;
        }
    }

    public void TakeDamage(float damage)
    {
        if (_isDead) return;

        currentHealth -= damage;
        currentHealth = Mathf.Max(0, currentHealth);
        OnHealthChanged?.Invoke(currentHealth, maxHealth);

        if (currentHealth <= 0)
        {
            Die();
        }
    }

    public void Heal(float amount)
    {
        if (_isDead) return;

        currentHealth += amount;
        currentHealth = Mathf.Min(currentHealth, maxHealth);
        OnHealthChanged?.Invoke(currentHealth, maxHealth);
    }

    public bool UseMana(float amount)
    {
        if (currentMana >= amount)
        {
            currentMana -= amount;
            OnManaChanged?.Invoke(currentMana, maxMana);
            return true;
        }
        return false;
    }

    public void RestoreMana(float amount)
    {
        currentMana += amount;
        currentMana = Mathf.Min(currentMana, maxMana);
        OnManaChanged?.Invoke(currentMana, maxMana);
    }

    public bool UseStamina(float amount)
    {
        if (currentStamina >= amount)
        {
            currentStamina -= amount;
            OnStaminaChanged?.Invoke(currentStamina, maxStamina);
            return true;
        }
        return false;
    }

    public void RestoreStamina(float amount)
    {
        currentStamina += amount;
        currentStamina = Mathf.Min(currentStamina, maxStamina);
        OnStaminaChanged?.Invoke(currentStamina, maxStamina);
    }

    public void AddEffect(StatusEffect effect)
    {
        StatusEffect existing = activeEffects.Find(e => e.id == effect.id);
        
        if (existing != null)
        {
            if (existing.currentStacks < existing.maxStacks)
            {
                existing.currentStacks++;
            }
            existing.remainingTime = existing.duration;
        }
        else
        {
            effect.currentStacks = 1;
            effect.remainingTime = effect.duration;
            effect.nextTickTime = Time.time;
            activeEffects.Add(effect);
            OnEffectAdded?.Invoke(effect);
        }
    }

    public void RemoveEffect(StatusEffect effect)
    {
        if (activeEffects.Remove(effect))
        {
            OnEffectRemoved?.Invoke(effect);
        }
    }

    public void ClearEffects()
    {
        foreach (var effect in activeEffects)
        {
            OnEffectRemoved?.Invoke(effect);
        }
        activeEffects.Clear();
    }

    public float GetEffectIntensity(string effectId)
    {
        StatusEffect effect = activeEffects.Find(e => e.id == effectId);
        if (effect != null)
        {
            return effect.intensity * effect.currentStacks;
        }
        return 0f;
    }

    public bool HasEffect(string effectId)
    {
        return activeEffects.Exists(e => e.id == effectId);
    }

    private void Die()
    {
        _isDead = true;
        OnPlayerDeath?.Invoke();
        Debug.Log("[PlayerStats] Player died!");
    }

    public void Revive(float healthAmount)
    {
        _isDead = false;
        currentHealth = healthAmount;
        OnHealthChanged?.Invoke(currentHealth, maxHealth);
        Debug.Log("[PlayerStats] Player revived!");
    }
}
