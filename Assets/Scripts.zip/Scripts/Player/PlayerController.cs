using UnityEngine;
using UnityEngine.InputSystem;
using TMPro;

/// <summary>
/// PLAYERCONTROLLER — Mouvement 3D avec le nouveau Input System (Unity 6)
///
/// SETUP dans Unity :
///  1. Ajoute un CharacterController sur ton GameObject joueur
///  2. Attache ce script sur le même GameObject
///  3. Assigne la Camera principale dans l'Inspector (champ "playerCamera")
///  4. Contrôles : WASD = déplacement | Espace = saut | Shift = sprint | Souris = regard | E = interact
/// </summary>
[RequireComponent(typeof(CharacterController))]
public class PlayerController : MonoBehaviour
{
    // ─── Paramètres Inspector ─────────────────────────────────────────────────
    [Header("Déplacement")]
    [SerializeField] private float walkSpeed   = 5f;
    [SerializeField] private float sprintSpeed = 9f;
    [SerializeField] private float jumpHeight  = 1.5f;
    [SerializeField] private float gravity     = -19.81f;

    [Header("Caméra (regard)")]
    [SerializeField] private Camera playerCamera;
    [SerializeField] private float mouseSensitivity = 0.2f;
    [SerializeField] private float maxLookAngle     = 80f;
    [SerializeField] private float eyeHeightOffset  = 0.6f;

    [Header("Stamina")]
    [SerializeField] private float maxStamina   = 100f;
    [SerializeField] private float staminaDrain = 20f;
    [SerializeField] private float staminaRegen = 10f;

    [Header("Interaction")]
    [SerializeField] private float interactionRange = 3f;
    [SerializeField] private LayerMask interactionLayer = ~0;
    [SerializeField] private LayerMask playerLayer = 0;
    [SerializeField] private TextMeshProUGUI interactionPromptText;

    // ─── Composants ───────────────────────────────────────────────────────────
    private CharacterController _controller;
    private Inventory _inventory;

    // ─── Input System ─────────────────────────────────────────────────────────
    private Keyboard _kb;
    private Mouse    _mouse;

    // ─── Variables internes ───────────────────────────────────────────────────
    private Vector3 _velocity;
    private float   _xRotation  = 0f;
    private bool    _isGrounded;
    private float   _currentStamina;
    private IInteractable _currentInteractable;
    private IInteractable _highlightedInteractable;

    // ─── Événements ───────────────────────────────────────────────────────────
    public static event System.Action<float, float> OnStaminaChanged;
    public static event System.Action<string> OnInteractableChanged;

    // ─── Propriétés ─────────────────────────────────────────────────────────
    public Inventory PlayerInventory => _inventory;
    public IInteractable CurrentInteractable => _currentInteractable;
    public bool HasInteractable => _currentInteractable != null;

    // ─────────────────────────────────────────────────────────────────────────
    void Awake()
    {
        _controller     = GetComponent<CharacterController>();
        
        if (_controller == null)
        {
            Debug.LogError("[PlayerController] CharacterController not found!");
            enabled = false;
            return;
        }

        _inventory      = GetComponent<Inventory>();
        _currentStamina = maxStamina;
        RefreshInputReferences();

        // Assure que l'inventaire existe
        if (_inventory == null)
        {
            _inventory = gameObject.AddComponent<Inventory>();
            Debug.Log("[PlayerController] Added Inventory component to player");
        }

        // Évite de rester coincé dans les murs
        _controller.skinWidth = 0.08f;
        _controller.minMoveDistance = 0.001f;

        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible   = false;

        // Positionne la caméra à hauteur des yeux
        if (playerCamera != null)
            playerCamera.transform.localPosition = new Vector3(0f, eyeHeightOffset, 0f);
    }

    void Update()
    {
        RefreshInputReferences();
        
        if (_kb == null || _mouse == null) return;

        if (GameManager.Instance != null &&
            GameManager.Instance.CurrentState != GameManager.GameState.Playing)
            return;

        HandleCursorInput();
        HandleMouseLook();
        HandleMovement();
        HandleStamina();
        HandleInteraction();
    }

    private void HandleCursorInput()
    {
        if (_kb.escapeKey.wasPressedThisFrame)
        {
            UnlockCursor();
            return;
        }

        if (Cursor.visible && _mouse.leftButton.wasPressedThisFrame)
        {
            LockCursor();
        }
    }

    void OnApplicationFocus(bool hasFocus)
    {
        if (!hasFocus && Cursor.lockState == CursorLockMode.Locked)
        {
            UnlockCursor();
        }
    }

    private void RefreshInputReferences()
    {
        _kb = Keyboard.current;
        _mouse = Mouse.current;
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  REGARD (souris)
    // ─────────────────────────────────────────────────────────────────────────
    private void HandleMouseLook()
    {
        if (Cursor.lockState != CursorLockMode.Locked) return;

        Vector2 mouseDelta = _mouse.delta.ReadValue() * mouseSensitivity;

        // Rotation horizontale → fait tourner tout le joueur
        transform.Rotate(Vector3.up * mouseDelta.x);

        // Rotation verticale → incline uniquement la caméra
        _xRotation -= mouseDelta.y;
        _xRotation  = Mathf.Clamp(_xRotation, -maxLookAngle, maxLookAngle);

        if (playerCamera != null)
            playerCamera.transform.localRotation = Quaternion.Euler(_xRotation, 0f, 0f);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  DÉPLACEMENT + SAUT + GRAVITÉ
    // ─────────────────────────────────────────────────────────────────────────
    private void HandleMovement()
    {
        if (Cursor.lockState != CursorLockMode.Locked) return;

        _isGrounded = _controller.isGrounded;

        if (_isGrounded && _velocity.y < 0)
            _velocity.y = -2f;

        // WASD + flèches directionnelles
        float horizontal = (_kb.dKey.isPressed || _kb.rightArrowKey.isPressed ? 1f : 0f)
                         - (_kb.aKey.isPressed || _kb.leftArrowKey.isPressed  ? 1f : 0f);
        float vertical   = (_kb.wKey.isPressed || _kb.upArrowKey.isPressed    ? 1f : 0f)
                         - (_kb.sKey.isPressed || _kb.downArrowKey.isPressed  ? 1f : 0f);

        Vector3 moveDir = transform.right * horizontal + transform.forward * vertical;

        bool isMoving    = _kb.wKey.isPressed || _kb.aKey.isPressed ||
                           _kb.sKey.isPressed || _kb.dKey.isPressed;
        bool isSprinting = _kb.leftShiftKey.isPressed && isMoving && _isGrounded && _currentStamina > 0f;
        float speed       = isSprinting ? sprintSpeed : walkSpeed;

        // Saut
        if (_kb.spaceKey.wasPressedThisFrame && _isGrounded)
            _velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);

        // Gravité
        _velocity.y += gravity * Time.deltaTime;

        // Combiner déplacement horizontal + gravité en un seul appel
        Vector3 finalMove = moveDir * speed * Time.deltaTime + _velocity * Time.deltaTime;
        _controller.Move(finalMove);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  STAMINA
    // ─────────────────────────────────────────────────────────────────────────
    private void HandleStamina()
    {
        bool isMoving    = _kb.wKey.isPressed || _kb.aKey.isPressed ||
                           _kb.sKey.isPressed || _kb.dKey.isPressed;
        bool isSprinting = _kb.leftShiftKey.isPressed && isMoving && _isGrounded && _currentStamina > 0f;

        if (isSprinting)
        {
            _currentStamina -= staminaDrain * Time.deltaTime;
            _currentStamina  = Mathf.Max(_currentStamina, 0f);
        }
        else
        {
            _currentStamina += staminaRegen * Time.deltaTime;
            _currentStamina  = Mathf.Min(_currentStamina, maxStamina);
        }

        OnStaminaChanged?.Invoke(_currentStamina, maxStamina);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  INTERACTION (E)
    // ─────────────────────────────────────────────────────────────────────────
    private void HandleInteraction()
    {
        if (_kb.eKey.wasPressedThisFrame && _currentInteractable != null)
        {
            if (_currentInteractable.CanInteract(this))
            {
                _currentInteractable.OnInteract(this);
            }
        }

        CheckForInteractable();
    }

    private void CheckForInteractable()
    {
        if (playerCamera == null) return;

        Ray ray = new Ray(playerCamera.transform.position, playerCamera.transform.forward);
        RaycastHit hit;

        // Exclure le player layer du raycast pour éviter de se détecter soi-même
        LayerMask effectiveLayer = interactionLayer & ~playerLayer;
        
        if (Physics.Raycast(ray, out hit, interactionRange, effectiveLayer))
        {
            IInteractable interactable = hit.collider.GetComponent<IInteractable>();

            if (interactable != null)
            {
                if (_highlightedInteractable != interactable)
                {
                    if (_highlightedInteractable != null)
                        _highlightedInteractable.OnHighlightExit(this);

                    _highlightedInteractable = interactable;
                    _highlightedInteractable.OnHighlightEnter(this);
                }

                _currentInteractable = interactable;
                UpdateInteractionPrompt(interactable.InteractionPrompt);
                OnInteractableChanged?.Invoke(interactable.InteractionPrompt);
                return;
            }
        }

        if (_highlightedInteractable != null)
        {
            _highlightedInteractable.OnHighlightExit(this);
            _highlightedInteractable = null;
        }

        _currentInteractable = null;
        ClearInteractionPrompt();
        OnInteractableChanged?.Invoke(string.Empty);
    }

    private void UpdateInteractionPrompt(string prompt)
    {
        if (interactionPromptText != null)
            interactionPromptText.text = $"[E] {prompt}";
    }

    private void ClearInteractionPrompt()
    {
        if (interactionPromptText != null)
            interactionPromptText.text = string.Empty;
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  UTILITAIRES
    // ─────────────────────────────────────────────────────────────────────────
    public void UnlockCursor()
    {
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible   = true;
    }

    public void LockCursor()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible   = false;
    }

    public bool IsGrounded => _isGrounded;
}
