using UnityEngine;

/// <summary>
/// PLAYERHEALTH — Gestion de la vie du joueur
/// 
/// SETUP dans Unity :
///  1. Attache ce script sur ton GameObject joueur
///  2. Configure maxHealth dans l'Inspector
///  3. Appelle TakeDamage(float) depuis n'importe quel ennemi ou piège
/// </summary>
public class PlayerHealth : MonoBehaviour
{
    // ─── Paramètres Inspector ─────────────────────────────────────────────────
    [Header("Vie")]
    [SerializeField] private float maxHealth         = 100f;
    [SerializeField] private float invincibilityTime = 0.5f; // Temps invincible après un coup

    [Header("Régénération (optionnel)")]
    [SerializeField] private bool  regenEnabled  = false;
    [SerializeField] private float regenAmount   = 5f;   // HP par seconde
    [SerializeField] private float regenDelay    = 3f;   // Délai avant regen (secondes)

    // ─── État ─────────────────────────────────────────────────────────────────
    public float CurrentHealth   { get; private set; }
    public bool  IsDead          { get; private set; }

    private float _lastDamageTime;
    private bool  _isInvincible;

    // ─── Événements ───────────────────────────────────────────────────────────
    public static event System.Action<float, float> OnHealthChanged; // (current, max)
    public static event System.Action               OnPlayerDied;
    public static event System.Action<float>        OnPlayerDamaged; // (dégâts reçus)

    // ─────────────────────────────────────────────────────────────────────────
    void Awake()
    {
        CurrentHealth = maxHealth;
    }

    void Start()
    {
        // Notifie l'UI dès le départ
        OnHealthChanged?.Invoke(CurrentHealth, maxHealth);
    }

    void Update()
    {
        // Fin de l'invincibilité temporaire
        if (_isInvincible && Time.time - _lastDamageTime > invincibilityTime)
            _isInvincible = false;

        // Régénération
        if (regenEnabled && !IsDead && CurrentHealth < maxHealth)
        {
            if (Time.time - _lastDamageTime >= regenDelay)
                Heal(regenAmount * Time.deltaTime);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  MÉTHODES PUBLIQUES
    // ─────────────────────────────────────────────────────────────────────────

    /// <summary>Inflige des dégâts au joueur.</summary>
    public void TakeDamage(float damage)
    {
        if (IsDead || _isInvincible) return;

        CurrentHealth    -= damage;
        CurrentHealth     = Mathf.Clamp(CurrentHealth, 0f, maxHealth);
        _lastDamageTime   = Time.time;
        _isInvincible     = true;

        OnHealthChanged?.Invoke(CurrentHealth, maxHealth);
        OnPlayerDamaged?.Invoke(damage);

        Debug.Log($"[PlayerHealth] Dégâts reçus : {damage} | Vie restante : {CurrentHealth}");

        if (CurrentHealth <= 0f)
            Die();
    }

    /// <summary>Soigne le joueur.</summary>
    public void Heal(float amount)
    {
        if (IsDead) return;

        CurrentHealth += amount;
        CurrentHealth  = Mathf.Clamp(CurrentHealth, 0f, maxHealth);

        OnHealthChanged?.Invoke(CurrentHealth, maxHealth);
    }

    /// <summary>Soigne complètement le joueur.</summary>
    public void FullHeal()
    {
        Heal(maxHealth);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  MORT
    // ─────────────────────────────────────────────────────────────────────────
    private void Die()
    {
        if (IsDead) return;
        IsDead = true;

        Debug.Log("[PlayerHealth] Le joueur est mort !");
        OnPlayerDied?.Invoke();
        GameManager.Instance?.TriggerGameOver();

        // Désactive les contrôles
        var controller = GetComponent<PlayerController>();
        if (controller != null) controller.enabled = false;
    }
}
