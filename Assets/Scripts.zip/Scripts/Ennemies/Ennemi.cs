using UnityEngine;

public class Ennemi : MonoBehaviour
{
    [Header("Combat")]
    [SerializeField] private float damage = 20f;

    private void OnCollisionEnter(Collision col)
    {
        if (col.gameObject.CompareTag("Player"))
        {
            var health = col.gameObject.GetComponent<PlayerHealth>();
            if (health == null)
            {
                Debug.LogWarning($"[Ennemi] {gameObject.name} collided with player but no PlayerHealth component found!");
                return;
            }
            health.TakeDamage(damage);
        }
    }
}
