# INTEGRATION GUIDE - Dungeon Maze Generator v2.0.0

**Target:** Code.Lavos Unity 6 Project  
**Integration Type:** Complete replacement of GridMazeGenerator8  
**Time Required:** 15-20 minutes  
**Difficulty:** Medium (follows plug-in-out architecture)

---

## QUICK START (5 MINUTES)

### Step 1: Copy Core Files

```bash
# Copy to Assets/Scripts/Core/Advanced/
cp DungeonMazeGenerator.cs Assets/Scripts/Core/06_Maze/
cp DungeonMazeData.cs Assets/Scripts/Core/06_Maze/
cp DungeonMazeConfig.cs Assets/Scripts/Core/06_Maze/
cp AIAdaptiveDifficulty.cs Assets/Scripts/Core/06_Maze/

# Copy Editor Tool
cp DungeonMazeEditorTool.cs Assets/Scripts/Editor/Maze/
```

### Step 2: Update Scene

In your maze scene, update `CompleteMazeBuilder.cs`:

```csharp
// OLD CODE (GridMazeGenerator8)
using Code.Lavos.Core;
var generator = new GridMazeGenerator8();
var mazeData = generator.Generate(seed, level, config);

// NEW CODE (DungeonMazeGenerator)
using Code.Lavos.Core.Advanced;
var generator = new DungeonMazeGenerator();
var mazeData = generator.Generate(seed, level, dungeonConfig);
```

### Step 3: Create Configuration

Create `Assets/Resources/Config/dungeon_default.json`:

```json
{
  "baseSize": 21,
  "minSize": 15,
  "maxSize": 51,
  "cellSize": 6.0,
  "wallHeight": 3.0,
  "spawnRoomSize": 2,
  "exitRoomSize": 2,
  "chamberExpansionRadius": 1,
  "trapDensity": 0.25,
  "treasureDensity": 0.15,
  "corridorWindingFactor": 0.3,
  "torchChance": 0.25,
  "enemyDensity": 0.03,
  "chestDensity": 0.05,
  "bossRoomCount": 1,
  "allowDiagonalWalls": true,
  "guaranteedPathRequired": true,
  "difficulty": {
    "baseFactor": 1.0,
    "factorPerLevel": 0.15,
    "maxFactor": 5.0,
    "sizeGrowthPerLevel": 2
  },
  "aiSettings": {
    "enableAdaptivity": true,
    "minAdaptiveFactor": 0.7,
    "maxAdaptiveFactor": 1.8,
    "pathLengthWeight": 0.3,
    "trapDensityWeight": 0.25,
    "treasureDensityWeight": 0.2,
    "mazeComplexityWeight": 0.25,
    "learnFromPlayerPerformance": true,
    "performanceHistoryLength": 5
  }
}
```

### Step 4: Test

1. Open your maze scene
2. Go to `Tools → Lavos → Dungeon Maze Generator`
3. Click "Generate Maze"
4. Verify maze appears with walls, traps, treasures

---

## DETAILED INTEGRATION

### Replace GridMazeGenerator8 Usage

**Find all references:**

```bash
grep -r "GridMazeGenerator8" Assets/Scripts/
grep -r "new GridMazeGenerator8" Assets/Scripts/
grep -r "GridMazeGenerator8()" Assets/Scripts/
```

**Update each file:**

```csharp
// File: Assets/Scripts/Core/06_Maze/CompleteMazeBuilder.cs
// OLD:
private GridMazeGenerator _generator = new GridMazeGenerator8();

// NEW:
private DungeonMazeGenerator _generator = new DungeonMazeGenerator();

// OLD:
_mazeData = _generator.Generate(currentSeed, currentLevel, _config.MazeCfg);

// NEW:
var dungeonConfig = DungeonMazeConfig.CreateDefault();
_mazeData = _generator.Generate(currentSeed, currentLevel, dungeonConfig);
```

### Update GameConfig Integration

**Option A: Extend GameConfig**

```csharp
// File: Assets/Scripts/Core/06_Maze/GameConfig.cs
public class GameConfig : MonoBehaviour
{
    public DungeonMazeConfig DungeonConfig { get; private set; }

    private void Start()
    {
        DungeonConfig = DungeonMazeConfig.CreateDefault();
        
        // Load from JSON if available
        var json = Resources.Load<TextAsset>("Config/dungeon_default");
        if (json != null)
        {
            DungeonConfig = DungeonMazeConfig.LoadFromJson(json.text);
        }
    }
}
```

**Option B: Separate Configuration**

```csharp
// Keep GameConfig.cs unchanged
// Create new DungeonMazeConfigManager.cs

public class DungeonMazeConfigManager : MonoBehaviour
{
    public static DungeonMazeConfig LoadConfig()
    {
        var json = Resources.Load<TextAsset>("Config/dungeon_default");
        if (json != null)
        {
            return DungeonMazeConfig.LoadFromJson(json.text);
        }
        return DungeonMazeConfig.CreateDefault();
    }
}
```

### Enable AI Difficulty Learning

**Update PlayerStats or GameManager:**

```csharp
public class GameManager : MonoBehaviour
{
    private AIAdaptiveDifficulty _aiDifficulty;

    public void OnLevelComplete(float completionTime, bool exitReached)
    {
        var metrics = new PlayerPerformanceMetrics
        {
            Level = CurrentLevel,
            CompletionTime = completionTime,
            ReachedExit = exitReached,
            EnemiesDefeated = PlayerController.EnemiesDefeated,
            TrapsDodged = PlayerController.TrapsDodged,
            DamageTaken = PlayerStats.DamageTaken,
        };

        float score = metrics.ComputePerformanceScore();
        _aiDifficulty.RecordPerformance(score);
        
        float nextAdjustment = _aiDifficulty.GetAdaptiveAdjustment();
        Debug.Log($"Next difficulty adjustment: {nextAdjustment:F2}x");
    }
}
```

### Update Editor Tools

**Delete old maze generation menu items:**

```csharp
// Remove or comment out these from old Editor scripts:
[MenuItem("Tools/Lavos/Generate Maze (Old)")]
[MenuItem("Tools/Lavos/Preview Maze (Old)")]
```

**New menu item now available:**

```
Tools → Lavos → Dungeon Maze Generator
```

---

## FILE STRUCTURE

After integration, your project should look like:

```
Assets/
├── Scripts/
│   ├── Core/
│   │   ├── 06_Maze/
│   │   │   ├── GridMazeGenerator8.cs          (keep for reference)
│   │   │   ├── DungeonMazeGenerator.cs        (NEW)
│   │   │   ├── DungeonMazeData.cs             (NEW)
│   │   │   ├── DungeonMazeConfig.cs           (NEW)
│   │   │   ├── AIAdaptiveDifficulty.cs        (NEW)
│   │   │   ├── CompleteMazeBuilder.cs         (UPDATED)
│   │   │   └── MazeData8.cs                   (keep for reference)
│   │   └── ...
│   ├── Editor/
│   │   ├── Maze/
│   │   │   ├── MazeBuilderEditor.cs           (keep)
│   │   │   └── DungeonMazeEditorTool.cs       (NEW)
│   │   └── ...
│   └── ...
├── Resources/
│   └── Config/
│       ├── GameConfig8-default.json           (keep)
│       └── dungeon_default.json               (NEW)
├── Docs/
│   ├── DUNGEON_MAZE_DOCUMENTATION.md          (NEW)
│   ├── INTEGRATION_GUIDE.md                   (NEW)
│   └── ...
└── ...
```

---

## MIGRATION CHECKLIST

- [ ] Copy all 4 core files to Assets/Scripts/Core/06_Maze/
- [ ] Copy editor tool to Assets/Scripts/Editor/Maze/
- [ ] Create dungeon_default.json in Assets/Resources/Config/
- [ ] Update CompleteMazeBuilder.cs imports
- [ ] Replace GridMazeGenerator8 with DungeonMazeGenerator
- [ ] Update all config creation calls
- [ ] Test maze generation in editor
- [ ] Update GameManager for AI learning (optional)
- [ ] Run full scene test
- [ ] Delete old GridMazeGenerator8.cs references (keep backup)
- [ ] Update documentation in Assets/Docs/
- [ ] Commit to Git with message "feat: advanced dungeon maze generator v2.0.0"

---

## BACKWARD COMPATIBILITY

### Keep GridMazeGenerator8

The advanced system is **fully compatible** with old code:

```csharp
// Both can coexist
var oldMaze = oldGenerator.Generate(seed, level, oldConfig);
var newMaze = newGenerator.Generate(seed, level, newConfig);
```

### Gradual Migration

You can migrate level by level:

```csharp
public MazeData Generate(int seed, int level, GameConfig config)
{
    if (level < 5)
    {
        // Use old system for levels 0-4
        return new GridMazeGenerator8().Generate(seed, level, config.MazeCfg);
    }
    else
    {
        // Use new system for levels 5+
        return new DungeonMazeGenerator().Generate(seed, level, newConfig);
    }
}
```

---

## TESTING CHECKLIST

### Unit Tests

```csharp
[Test]
public void TestDungeonGeneration()
{
    var config = DungeonMazeConfig.CreateDefault();
    var gen = new DungeonMazeGenerator();
    var maze = gen.Generate(12345, 0, config);
    
    Assert.IsNotNull(maze);
    Assert.Greater(maze.Width, 0);
    Assert.Greater(maze.Height, 0);
}

[Test]
public void TestAIDifficulty()
{
    var config = DungeonMazeConfig.CreateDefault();
    var gen = new DungeonMazeGenerator();
    var maze = gen.Generate(12345, 3, config);
    
    Assert.Greater(maze.AIAdaptiveFactor, 0);
    Assert.LessOrEqual(maze.AIAdaptiveFactor, 3.0f);
}
```

### Integration Tests

```csharp
// Test in actual scene
[Test]
public void TestSceneIntegration()
{
    var sceneSetup = SceneManager.LoadScene("MazeScene", LoadSceneMode.Additive);
    yield return null;
    
    var mazeBuilder = FindObjectOfType<CompleteMazeBuilder>();
    Assert.IsNotNull(mazeBuilder);
    
    mazeBuilder.GenerateMaze();
    yield return null;
    
    Assert.IsNotNull(mazeBuilder.MazeData);
}
```

### Editor Verification

1. Open Editor Tool: `Tools → Lavos → Dungeon Maze Generator`
2. Adjust parameters:
   - Trap Density: 0.5 (high traps)
   - Treasure Density: 0.3 (many treasures)
   - Winding Factor: 0.7 (complex)
3. Click "Generate Maze"
4. Verify in scene view:
   - Red cubes = trap rooms
   - Yellow cubes = treasure rooms
   - Green cube = spawn
   - Cyan cube = exit

---

## TROUBLESHOOTING INTEGRATION

### Error: "Type or namespace 'DungeonMazeGenerator' not found"

**Cause:** Files not in correct folder  
**Fix:** Ensure files are in `Assets/Scripts/Core/06_Maze/`

```csharp
using Code.Lavos.Core.Advanced;  // Check namespace!
```

### Error: "SerializationException: Unknown type 'AIAdaptiveSettings'"

**Cause:** Newtonsoft.Json not available  
**Fix:** Ensure package is in manifest:

```json
// Packages/manifest.json
{
  "dependencies": {
    "com.unity.nuget.newtonsoft-json": "3.2.1"
  }
}
```

### Maze has no diagonal walls

**Cause:** `AllowDiagonalWalls = false` in config  
**Fix:** Update JSON:

```json
{
  "allowDiagonalWalls": true
}
```

### Generator is slow

**Cause:** Maze size too large or winding factor too high  
**Fix:** Adjust config:

```json
{
  "maxSize": 35,
  "corridorWindingFactor": 0.2
}
```

---

## COMMIT MESSAGE

When committing to Git:

```
feat: add advanced dungeon maze generator v2.0.0

- Replace GridMazeGenerator8 with DungeonMazeGenerator
- Add AI-based adaptive difficulty system
- Implement trap/treasure room placement
- Add complete editor tool with preview
- Support multi-corridor entrance/exit
- Add JSON configuration system
- Maintain backward compatibility with old system

BREAKING CHANGE: GridMazeGenerator8 superseded (kept for reference)
Closes #142
```

---

## POST-INTEGRATION

### Documentation Updates

Update your project's `Assets/Docs/` folder:

1. Copy `DUNGEON_MAZE_DOCUMENTATION.md`
2. Create `INTEGRATION_GUIDE.md` (this file)
3. Update `README.md` with dungeon features
4. Update `ARCHITECTURE_OVERVIEW.md`

### Git History

Keep the old system:

```bash
# Don't delete, just mark as deprecated
git mv Assets/Scripts/Core/06_Maze/GridMazeGenerator8.cs \
        Assets/Scripts/Deprecated/GridMazeGenerator8_Legacy.cs
```

### Team Communication

Notify your team:

```
Subject: Dungeon Maze Generator v2.0.0 now available

Hey team!

The advanced dungeon maze system is ready. Key features:
- AI-based difficulty scaling
- Trap and treasure placement
- Multi-corridor support
- Real-time editor preview

Follow INTEGRATION_GUIDE.md to update your scene.

Questions? Check the docs or ask in #development.
```

---

## NEXT STEPS

1. **Test thoroughly** in your existing scenes
2. **Integrate AI learning** into GameManager
3. **Tune parameters** for your game balance
4. **Create content** specific to your game world
5. **Profile performance** and optimize as needed
6. **Gather player feedback** and adjust difficulty

---

**Integration Guide v1.0**  
**For Dungeon Maze Generator v2.0.0**  
**BetsyBoop - 2026-03-07**
